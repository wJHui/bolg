-- -----------------------------
-- Yzncms MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : yzncms
-- 
-- Part : #1
-- Date : 2019-02-19 23:33:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `yzn_addons`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_addons`;
CREATE TABLE `yzn_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `yzn_addons`
-- -----------------------------
INSERT INTO `yzn_addons` VALUES ('2', 'database', '数据库备份', '简单的数据库备份', '1', '{\"path\":\"\\/Data\\/\",\"part\":\"20971520\",\"compress\":\"1\",\"level\":\"9\"}', '御宅男', '1.0.0', '1549519396', '1');
INSERT INTO `yzn_addons` VALUES ('3', 'returntop', '返回顶部', '回到顶部美化，随机或指定显示，100款样式，每天一种换，天天都用新样式', '1', '{\"random\":\"0\",\"current\":\"1\"}', '御宅男', '1.0.0', '1549519403', '0');

-- -----------------------------
-- Table structure for `yzn_admin`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_admin`;
CREATE TABLE `yzn_admin` (
  `userid` smallint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(20) DEFAULT NULL COMMENT '管理账号',
  `password` varchar(32) DEFAULT NULL COMMENT '管理密码',
  `roleid` tinyint(4) unsigned DEFAULT '0',
  `encrypt` varchar(6) DEFAULT NULL COMMENT '加密因子',
  `nickname` char(16) NOT NULL COMMENT '昵称',
  `last_login_time` int(10) unsigned DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) unsigned DEFAULT '0' COMMENT '最后登录IP',
  `email` varchar(40) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- -----------------------------
-- Records of `yzn_admin`
-- -----------------------------
INSERT INTO `yzn_admin` VALUES ('1', 'admin', '9724b5e6c56b95f5723009ef81961bfe', '1', 'Wo0bAa', '御宅男', '1550582450', '2130706433', '530765310@qq.com', '1');

-- -----------------------------
-- Table structure for `yzn_adminlog`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_adminlog`;
CREATE TABLE `yzn_adminlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `uid` smallint(3) NOT NULL DEFAULT '0' COMMENT '操作者ID',
  `info` text COMMENT '说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` bigint(20) unsigned NOT NULL DEFAULT '0',
  `get` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=624 DEFAULT CHARSET=utf8 COMMENT='操作日志';

-- -----------------------------
-- Records of `yzn_adminlog`
-- -----------------------------
INSERT INTO `yzn_adminlog` VALUES ('1', '1', '1', '提示语:清理缓存', '1546921637', '2130706433', '/admin/index/cache.html?type=all&_=1546921634521');
INSERT INTO `yzn_adminlog` VALUES ('2', '1', '1', '提示语:清理缓存', '1546921755', '2130706433', '/admin/index/cache.html?type=all&_=1546921750822');
INSERT INTO `yzn_adminlog` VALUES ('3', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546921908', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('4', '1', '1', '提示语:清理缓存', '1546924162', '2130706433', '/admin/index/cache.html?type=all&_=1546923544343');
INSERT INTO `yzn_adminlog` VALUES ('5', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546924281', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('6', '0', '0', '提示语:请先登陆', '1546924697', '2130706433', '/admin/');
INSERT INTO `yzn_adminlog` VALUES ('7', '1', '1', '提示语:恭喜您，登陆成功', '1546924702', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('8', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1546924713', '2130706433', '/addons/addons/install.html');
INSERT INTO `yzn_adminlog` VALUES ('9', '0', '0', '提示语:请先登陆', '1546928128', '2130706433', '/admin/');
INSERT INTO `yzn_adminlog` VALUES ('10', '1', '1', '提示语:恭喜您，登陆成功', '1546928135', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('11', '1', '1', '提示语:更新成功！', '1546928515', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('12', '1', '1', '提示语:更新成功！', '1546928523', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('13', '1', '1', '提示语:清理缓存', '1546928581', '2130706433', '/admin/index/cache.html?type=all&_=1546928136838');
INSERT INTO `yzn_adminlog` VALUES ('14', '1', '1', '提示语:更新成功！', '1546928688', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('15', '1', '1', '提示语:更新成功！', '1546928693', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('16', '1', '1', '提示语:更新成功！', '1546928696', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('17', '1', '1', '提示语:更新成功！', '1546928709', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('18', '1', '1', '提示语:更新成功！', '1546928713', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('19', '1', '1', '提示语:更新成功！', '1546928716', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('20', '1', '1', '提示语:更新成功！', '1546928879', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('21', '1', '1', '提示语:更新成功！', '1546928999', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('22', '1', '1', '提示语:更新成功！', '1546929003', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('23', '1', '1', '提示语:更新成功！清理缓存生效！', '1546929049', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('24', '1', '1', '提示语:更新成功！清理缓存生效！', '1546929106', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('25', '1', '1', '提示语:更新成功！清理缓存生效！', '1546929110', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('26', '1', '1', '提示语:插件卸载成功！清除浏览器缓存和框架缓存后生效！', '1546929123', '2130706433', '/addons/addons/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('27', '1', '1', '提示语:更新成功！清理缓存生效！', '1546929131', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('28', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546929216', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('29', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546929226', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('30', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546929242', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('31', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546929970', '2130706433', '/template/theme/chose/theme/blue1.html');
INSERT INTO `yzn_adminlog` VALUES ('32', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546930057', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('33', '0', '1', '提示语:主题名称不能为空且必须为纯字母！', '1546930060', '2130706433', '/template/theme/chose/theme/blue1.html');
INSERT INTO `yzn_adminlog` VALUES ('34', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546930140', '2130706433', '/template/theme/chose/theme/blue.html');
INSERT INTO `yzn_adminlog` VALUES ('35', '1', '1', '提示语:更新成功！请及时清理缓存！', '1546930143', '2130706433', '/template/theme/chose/theme/default.html');
INSERT INTO `yzn_adminlog` VALUES ('36', '1', '1', '提示语:添加成功！', '1546930245', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('37', '1', '1', '提示语:添加成功！', '1546930447', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('38', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546930600', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('39', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546930606', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('40', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546930709', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('41', '0', '1', '提示语:该模块要求系统最低版本为：1.0.1！', '1546930711', '2130706433', '/admin/module/install.html?module=cms');
INSERT INTO `yzn_adminlog` VALUES ('42', '0', '1', '提示语:该模块要求系统最低版本为：1.0.1！', '1546930715', '2130706433', '/admin/module/install.html?module=cms');
INSERT INTO `yzn_adminlog` VALUES ('43', '0', '1', '提示语:该模块要求系统最低版本为：1.0.1！', '1546930717', '2130706433', '/admin/module/install.html?module=cms');
INSERT INTO `yzn_adminlog` VALUES ('44', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546932707', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('45', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546932710', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('46', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546934987', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('47', '1', '1', '提示语:清理缓存', '1546936098', '2130706433', '/admin/index/cache.html?type=all&_=1546934991562');
INSERT INTO `yzn_adminlog` VALUES ('48', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546936608', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('49', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546936788', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('50', '0', '0', '提示语:请先登陆', '1546940757', '2130706433', '/admin/');
INSERT INTO `yzn_adminlog` VALUES ('51', '1', '1', '提示语:恭喜您，登陆成功', '1546940765', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('52', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546941125', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('53', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546941156', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('54', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546944554', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('55', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1546944558', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('56', '1', '1', '提示语:模块卸载成功！清除浏览器缓存和框架缓存后生效！', '1546944601', '2130706433', '/admin/module/uninstall.html');
INSERT INTO `yzn_adminlog` VALUES ('57', '0', '0', '提示语:请先登陆', '1547997108', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('58', '1', '1', '提示语:恭喜您，登陆成功', '1547997121', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('59', '1', '1', '提示语:模块安装成功！清除浏览器缓存和框架缓存后生效！', '1547997178', '2130706433', '/admin/module/install.html');
INSERT INTO `yzn_adminlog` VALUES ('60', '0', '1', '提示语:所属模型不得为空', '1547997769', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('61', '0', '1', '提示语:所属模型不得为空', '1547997770', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('62', '1', '1', '提示语:添加成功！', '1547997776', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('63', '1', '1', '提示语:操作成功！', '1547997815', '2130706433', '/cms/cms/add/catid/1.html');
INSERT INTO `yzn_adminlog` VALUES ('64', '0', '0', '提示语:请先登陆', '1548337402', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('65', '0', '0', '提示语:密码错误！', '1548337413', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('66', '0', '0', '提示语:密码错误！', '1548337419', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('67', '0', '0', '提示语:密码错误！', '1548337435', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('68', '1', '1', '提示语:恭喜您，登陆成功', '1548337441', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('69', '0', '0', '提示语:请先登陆', '1548337653', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('70', '1', '1', '提示语:编辑成功！', '1548337926', '2130706433', '/cms/cms/edit/catid/1.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('71', '0', '0', '提示语:请先登陆', '1548512709', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('72', '0', '0', '提示语:请先登陆', '1548512709', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('73', '0', '0', '提示语:请先登陆', '1548512718', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('74', '0', '0', '提示语:请先登陆', '1548512719', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('75', '1', '1', '提示语:恭喜您，登陆成功', '1548512730', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('76', '1', '1', '提示语:清理缓存', '1548512748', '2130706433', '/admin/index/cache.html?type=all&_=1548512739706');
INSERT INTO `yzn_adminlog` VALUES ('77', '0', '0', '提示语:请先登陆', '1548855461', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('78', '0', '0', '提示语:请先登陆', '1548855462', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('79', '0', '0', '提示语:请先登陆', '1548855464', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('80', '1', '1', '提示语:恭喜您，登陆成功', '1548855473', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('81', '0', '0', '提示语:请先登陆', '1549246870', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('82', '0', '0', '提示语:请先登陆', '1549246871', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('83', '1', '1', '提示语:恭喜您，登陆成功', '1549246888', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('84', '0', '0', '提示语:请先登陆', '1549292618', '2130706433', '/admin/');
INSERT INTO `yzn_adminlog` VALUES ('85', '1', '1', '提示语:恭喜您，登陆成功', '1549292637', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('86', '1', '1', '提示语:编辑成功！', '1549292678', '2130706433', '/cms/cms/edit/catid/1.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('87', '0', '0', '提示语:请先登陆', '1549337326', '2130706433', '/admin/');
INSERT INTO `yzn_adminlog` VALUES ('88', '1', '1', '提示语:恭喜您，登陆成功', '1549337356', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('89', '1', '1', '提示语:编辑成功！', '1549338250', '2130706433', '/cms/cms/edit/catid/1.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('90', '1', '1', '提示语:修改成功！', '1549338315', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('91', '1', '1', '提示语:编辑成功！', '1549342778', '2130706433', '/cms/cms/edit/catid/1.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('92', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'image\'', '1549343082', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('93', '1', '1', '提示语:新增成功', '1549343109', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('94', '1', '1', '提示语:编辑成功！', '1549343161', '2130706433', '/cms/cms/edit/catid/1.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('95', '1', '1', '提示语:操作成功！', '1549343536', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('96', '1', '1', '提示语:操作成功！', '1549343537', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('97', '1', '1', '提示语:菜单排序成功！', '1549343553', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('98', '0', '0', '提示语:请先登陆', '1549380006', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('99', '0', '0', '提示语:请先登陆', '1549380007', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('100', '1', '1', '提示语:恭喜您，登陆成功', '1549380158', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('101', '1', '1', '提示语:添加模型成功！', '1549385987', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('102', '1', '1', '提示语:模型修改成功！', '1549386014', '2130706433', '/cms/models/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('103', '1', '1', '提示语:添加成功！', '1549386106', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('104', '0', '0', '提示语:请先登陆', '1549422236', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('105', '1', '1', '提示语:恭喜您，登陆成功', '1549422250', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('106', '0', '0', '提示语:请先登陆', '1549517527', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('107', '1', '1', '提示语:恭喜您，登陆成功', '1549517540', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('108', '1', '1', '提示语:更新缓存成功！', '1549519056', '2130706433', '/cms/category/public_cache.html');
INSERT INTO `yzn_adminlog` VALUES ('109', '1', '1', '提示语:模型修改成功！', '1549519097', '2130706433', '/cms/models/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('110', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1549519396', '2130706433', '/addons/addons/install.html');
INSERT INTO `yzn_adminlog` VALUES ('111', '1', '1', '提示语:插件安装成功！清除浏览器缓存和框架缓存后生效！', '1549519404', '2130706433', '/addons/addons/install.html');
INSERT INTO `yzn_adminlog` VALUES ('112', '1', '1', '提示语:清理缓存', '1549519410', '2130706433', '/admin/index/cache.html?type=all&_=1549517542030');
INSERT INTO `yzn_adminlog` VALUES ('113', '1', '1', '提示语:添加模型成功！', '1549529187', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('114', '0', '1', '提示语:字段名称只能为字母和数字', '1549529294', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('115', '0', '1', '提示语:字段名称只能为字母和数字', '1549529299', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('116', '0', '1', '提示语:字段名称只能为字母和数字', '1549529303', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('117', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549529317', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('118', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549529329', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('119', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549529333', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('120', '0', '1', '提示语:字段名称只能为字母和数字', '1549529390', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('121', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'languments\'', '1549529459', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('122', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'lantype\'', '1549529553', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('123', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'lantype\'', '1549529558', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('124', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'fgfdgfdg\'', '1549529568', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('125', '1', '1', '提示语:添加成功！', '1549529646', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('126', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'lang\'', '1549529712', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('127', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'langs\'', '1549529720', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('128', '1', '1', '提示语:操作成功！', '1549529756', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('129', '0', '1', '提示语:字段标题只能为只能是汉字', '1549529965', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('130', '1', '1', '提示语:新增成功', '1549529974', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('131', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549530078', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('132', '1', '1', '提示语:新增成功', '1549530165', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('133', '1', '1', '提示语:清理缓存', '1549530221', '2130706433', '/admin/index/cache.html?type=all&_=1549530213325');
INSERT INTO `yzn_adminlog` VALUES ('134', '1', '1', '提示语:字段删除成功！', '1549530283', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('135', '1', '1', '提示语:字段删除成功！', '1549530288', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('136', '1', '1', '提示语:删除成功！', '1549530333', '2130706433', '/cms/cms/delete/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('137', '1', '1', '提示语:新增成功', '1549530440', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('138', '1', '1', '提示语:字段删除成功！', '1549530469', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('139', '1', '1', '提示语:更新缓存成功！', '1549530761', '2130706433', '/cms/category/public_cache.html');
INSERT INTO `yzn_adminlog` VALUES ('140', '1', '1', '提示语:删除成功！', '1549530798', '2130706433', '/admin/manager/del.html');
INSERT INTO `yzn_adminlog` VALUES ('141', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'dfdf\'', '1549530907', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('142', '0', '1', '提示语:参数错误！', '1549530939', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('143', '0', '1', '提示语:该页面不存在！', '1549530939', '2130706433', '/cms/field/__CDN__/assets/img/favicon.ico');
INSERT INTO `yzn_adminlog` VALUES ('144', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'dfdf\'', '1549531506', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('145', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'dfdf\'', '1549531509', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('146', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'dfdf\'', '1549531523', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('147', '0', '0', '提示语:请先登陆', '1549563319', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('148', '1', '1', '提示语:恭喜您，登陆成功', '1549563349', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('149', '1', '1', '提示语:新增成功', '1549563671', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('150', '0', '1', '提示语:SQLSTATE[42000]: Syntax error or access violation: 1091 Can\'t DROP \'abc\'; check that column/key exists', '1549564221', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('151', '1', '1', '提示语:清理缓存', '1549564227', '2130706433', '/admin/index/cache.html?type=all&_=1549564210853');
INSERT INTO `yzn_adminlog` VALUES ('152', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549564575', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('153', '1', '1', '提示语:新增成功', '1549564796', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('154', '1', '1', '提示语:设置更新成功', '1549565314', '2130706433', '/admin/config/setting/group/system.html');
INSERT INTO `yzn_adminlog` VALUES ('155', '1', '1', '提示语:设置更新成功', '1549565326', '2130706433', '/admin/config/setting/group/system.html');
INSERT INTO `yzn_adminlog` VALUES ('156', '1', '1', '提示语:新增成功', '1549565689', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('157', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'codetype\'', '1549565822', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('158', '1', '1', '提示语:新增成功', '1549565853', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('159', '1', '1', '提示语:修改成功！', '1549565937', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('160', '1', '1', '提示语:修改成功！', '1549565956', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('161', '0', '0', '提示语:请先登陆', '1549590411', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('162', '1', '1', '提示语:恭喜您，登陆成功', '1549590446', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('163', '0', '1', '提示语:字段标题只能为只能是汉字', '1549592857', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('164', '1', '1', '提示语:新增成功', '1549592880', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('165', '0', '1', '提示语:该栏目不存在！', '1549593761', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('166', '0', '1', '提示语:该栏目不存在！', '1549593761', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('167', '0', '1', '提示语:该栏目不存在！', '1549593761', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('168', '0', '1', '提示语:该栏目不存在！', '1549593761', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/fold/foldgutter.css');
INSERT INTO `yzn_adminlog` VALUES ('169', '0', '1', '提示语:该栏目不存在！', '1549593762', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.js');
INSERT INTO `yzn_adminlog` VALUES ('170', '0', '1', '提示语:该栏目不存在！', '1549593762', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/modes.min.js');
INSERT INTO `yzn_adminlog` VALUES ('171', '0', '1', '提示语:该栏目不存在！', '1549593762', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addons.min.js');
INSERT INTO `yzn_adminlog` VALUES ('172', '0', '1', '提示语:该栏目不存在！', '1549593762', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/theme/pastel-on-dark.css');
INSERT INTO `yzn_adminlog` VALUES ('173', '0', '1', '提示语:该栏目不存在！', '1549593762', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dmarked.min.js');
INSERT INTO `yzn_adminlog` VALUES ('174', '0', '1', '提示语:该栏目不存在！', '1549593763', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('175', '0', '1', '提示语:该栏目不存在！', '1549593763', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/theme/pastel-on-dark.css');
INSERT INTO `yzn_adminlog` VALUES ('176', '0', '1', '提示语:该栏目不存在！', '1549593763', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('177', '0', '1', '提示语:该栏目不存在！', '1549593763', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/fold/foldgutter.css');
INSERT INTO `yzn_adminlog` VALUES ('178', '0', '1', '提示语:该栏目不存在！', '1549593764', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('179', '0', '1', '提示语:该栏目不存在！', '1549593863', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.js');
INSERT INTO `yzn_adminlog` VALUES ('180', '0', '1', '提示语:该栏目不存在！', '1549593863', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('181', '0', '1', '提示语:该栏目不存在！', '1549593864', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('182', '0', '1', '提示语:该栏目不存在！', '1549593864', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/fold/foldgutter.css');
INSERT INTO `yzn_adminlog` VALUES ('183', '0', '1', '提示语:该栏目不存在！', '1549593864', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('184', '0', '1', '提示语:该栏目不存在！', '1549593869', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('185', '0', '1', '提示语:该栏目不存在！', '1549593869', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('186', '0', '1', '提示语:该栏目不存在！', '1549593869', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('187', '0', '1', '提示语:该栏目不存在！', '1549593869', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/fold/foldgutter.css');
INSERT INTO `yzn_adminlog` VALUES ('188', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('189', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('190', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/fold/foldgutter.css');
INSERT INTO `yzn_adminlog` VALUES ('191', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/codemirror.min.js');
INSERT INTO `yzn_adminlog` VALUES ('192', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/modes.min.js');
INSERT INTO `yzn_adminlog` VALUES ('193', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addons.min.js');
INSERT INTO `yzn_adminlog` VALUES ('194', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/theme/pastel-on-dark.css');
INSERT INTO `yzn_adminlog` VALUES ('195', '0', '1', '提示语:该栏目不存在！', '1549593912', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dmarked.min.js');
INSERT INTO `yzn_adminlog` VALUES ('196', '0', '1', '提示语:该栏目不存在！', '1549593913', '2130706433', '/cms/cms/add/catid/%7B/static/libs/ueditor/%7Dcodemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('197', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('198', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('199', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/codemirror.min.js');
INSERT INTO `yzn_adminlog` VALUES ('200', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('201', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/modes.min.js');
INSERT INTO `yzn_adminlog` VALUES ('202', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/addons.min.js');
INSERT INTO `yzn_adminlog` VALUES ('203', '0', '1', '提示语:该栏目不存在！', '1549594388', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/theme/pastel-on-dark.css');
INSERT INTO `yzn_adminlog` VALUES ('204', '0', '1', '提示语:该栏目不存在！', '1549594389', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/marked.min.js');
INSERT INTO `yzn_adminlog` VALUES ('205', '0', '1', '提示语:该栏目不存在！', '1549594393', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/addon/search/matchesonscrollbar.css');
INSERT INTO `yzn_adminlog` VALUES ('206', '0', '1', '提示语:该栏目不存在！', '1549594393', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/theme/pastel-on-dark.css');
INSERT INTO `yzn_adminlog` VALUES ('207', '0', '1', '提示语:该栏目不存在！', '1549594393', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/addon/dialog/dialog.css');
INSERT INTO `yzn_adminlog` VALUES ('208', '0', '1', '提示语:该栏目不存在！', '1549594393', '2130706433', '/cms/cms/add/catid/lib/js/editor.md-master/lib/codemirror/codemirror.min.css');
INSERT INTO `yzn_adminlog` VALUES ('209', '0', '0', '提示语:请先登陆', '1549600073', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('210', '1', '1', '提示语:恭喜您，登陆成功', '1549600085', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('211', '0', '1', '提示语:\'标题\'必须填写~', '1549600216', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('212', '0', '1', '提示语:\'标题\'必须填写~', '1549600271', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('213', '0', '1', '提示语:\'标题\'必须填写~', '1549600545', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('214', '0', '1', '提示语:\'标题\'必须填写~', '1549600812', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('215', '0', '1', '提示语:\'编程语言\'必须填写~', '1549600845', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('216', '1', '1', '提示语:操作成功！', '1549600852', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('217', '1', '1', '提示语:清理缓存', '1549603904', '2130706433', '/admin/index/cache.html?type=all&_=1549603796332');
INSERT INTO `yzn_adminlog` VALUES ('218', '0', '0', '提示语:请先登陆', '1549635126', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('219', '1', '1', '提示语:恭喜您，登陆成功', '1549635141', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('220', '0', '0', '提示语:请先登陆', '1549635389', '2130706433', '/admin/index/index.html');
INSERT INTO `yzn_adminlog` VALUES ('221', '0', '0', '提示语:请先登陆', '1549635390', '2130706433', '/admin/index/__CDN__/assets/img/favicon.ico');
INSERT INTO `yzn_adminlog` VALUES ('222', '1', '1', '提示语:恭喜您，登陆成功', '1549635400', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('223', '0', '0', '提示语:请先登陆', '1549635475', '2130706433', '/admin/index/index.html');
INSERT INTO `yzn_adminlog` VALUES ('224', '0', '0', '提示语:请先登陆', '1549635476', '2130706433', '/admin/index/__CDN__/assets/img/favicon.ico');
INSERT INTO `yzn_adminlog` VALUES ('225', '1', '1', '提示语:恭喜您，登陆成功', '1549635487', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('226', '1', '1', '提示语:清理缓存', '1549636917', '2130706433', '/admin/index/cache.html?type=all&_=1549636685117');
INSERT INTO `yzn_adminlog` VALUES ('227', '0', '0', '提示语:请先登陆', '1549637145', '2130706433', '/admin/index/index.html');
INSERT INTO `yzn_adminlog` VALUES ('228', '0', '0', '提示语:请先登陆', '1549637145', '2130706433', '/admin/index/__CDN__/assets/img/favicon.ico');
INSERT INTO `yzn_adminlog` VALUES ('229', '1', '1', '提示语:恭喜您，登陆成功', '1549637158', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('230', '0', '0', '提示语:请先登陆', '1549637443', '2130706433', '/admin/index/index.html');
INSERT INTO `yzn_adminlog` VALUES ('231', '0', '0', '提示语:请先登陆', '1549637443', '2130706433', '/admin/index/__CDN__/assets/img/favicon.ico');
INSERT INTO `yzn_adminlog` VALUES ('232', '1', '1', '提示语:清理缓存', '1549637507', '2130706433', '/admin/index/cache.html?type=all&_=1549637490412');
INSERT INTO `yzn_adminlog` VALUES ('233', '1', '1', '提示语:清理缓存', '1549639489', '2130706433', '/admin/index/cache.html?type=all&_=1549639054260');
INSERT INTO `yzn_adminlog` VALUES ('234', '1', '1', '提示语:清理缓存', '1549639528', '2130706433', '/admin/index/cache.html?type=all&_=1549639492018');
INSERT INTO `yzn_adminlog` VALUES ('235', '1', '1', '提示语:清理缓存', '1549639771', '2130706433', '/admin/index/cache.html?type=all&_=1549639492019');
INSERT INTO `yzn_adminlog` VALUES ('236', '1', '1', '提示语:初始化成功！', '1549639857', '2130706433', '/addons/database/export/isadmin/1.html');
INSERT INTO `yzn_adminlog` VALUES ('237', '1', '1', '提示语:备份完成！', '1549639858', '2130706433', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `yzn_adminlog` VALUES ('238', '1', '1', '提示语:备份完成！', '1549639858', '2130706433', '/addons/database/export/isadmin/1.html?id=1&start=0');
INSERT INTO `yzn_adminlog` VALUES ('239', '1', '1', '提示语:备份完成！', '1549639858', '2130706433', '/addons/database/export/isadmin/1.html?id=2&start=0');
INSERT INTO `yzn_adminlog` VALUES ('240', '1', '1', '提示语:备份完成！', '1549639858', '2130706433', '/addons/database/export/isadmin/1.html?id=3&start=0');
INSERT INTO `yzn_adminlog` VALUES ('241', '1', '1', '提示语:备份完成！', '1549639859', '2130706433', '/addons/database/export/isadmin/1.html?id=4&start=0');
INSERT INTO `yzn_adminlog` VALUES ('242', '1', '1', '提示语:备份完成！', '1549639859', '2130706433', '/addons/database/export/isadmin/1.html?id=5&start=0');
INSERT INTO `yzn_adminlog` VALUES ('243', '1', '1', '提示语:备份完成！', '1549639859', '2130706433', '/addons/database/export/isadmin/1.html?id=6&start=0');
INSERT INTO `yzn_adminlog` VALUES ('244', '1', '1', '提示语:备份完成！', '1549639859', '2130706433', '/addons/database/export/isadmin/1.html?id=7&start=0');
INSERT INTO `yzn_adminlog` VALUES ('245', '1', '1', '提示语:备份完成！', '1549639860', '2130706433', '/addons/database/export/isadmin/1.html?id=8&start=0');
INSERT INTO `yzn_adminlog` VALUES ('246', '1', '1', '提示语:备份完成！', '1549639860', '2130706433', '/addons/database/export/isadmin/1.html?id=9&start=0');
INSERT INTO `yzn_adminlog` VALUES ('247', '1', '1', '提示语:备份完成！', '1549639860', '2130706433', '/addons/database/export/isadmin/1.html?id=10&start=0');
INSERT INTO `yzn_adminlog` VALUES ('248', '1', '1', '提示语:备份完成！', '1549639860', '2130706433', '/addons/database/export/isadmin/1.html?id=11&start=0');
INSERT INTO `yzn_adminlog` VALUES ('249', '1', '1', '提示语:备份完成！', '1549639861', '2130706433', '/addons/database/export/isadmin/1.html?id=12&start=0');
INSERT INTO `yzn_adminlog` VALUES ('250', '1', '1', '提示语:备份完成！', '1549639861', '2130706433', '/addons/database/export/isadmin/1.html?id=13&start=0');
INSERT INTO `yzn_adminlog` VALUES ('251', '1', '1', '提示语:备份完成！', '1549639861', '2130706433', '/addons/database/export/isadmin/1.html?id=14&start=0');
INSERT INTO `yzn_adminlog` VALUES ('252', '1', '1', '提示语:备份完成！', '1549639861', '2130706433', '/addons/database/export/isadmin/1.html?id=15&start=0');
INSERT INTO `yzn_adminlog` VALUES ('253', '1', '1', '提示语:备份完成！', '1549639861', '2130706433', '/addons/database/export/isadmin/1.html?id=16&start=0');
INSERT INTO `yzn_adminlog` VALUES ('254', '1', '1', '提示语:备份完成！', '1549639862', '2130706433', '/addons/database/export/isadmin/1.html?id=17&start=0');
INSERT INTO `yzn_adminlog` VALUES ('255', '1', '1', '提示语:备份完成！', '1549639862', '2130706433', '/addons/database/export/isadmin/1.html?id=18&start=0');
INSERT INTO `yzn_adminlog` VALUES ('256', '1', '1', '提示语:备份完成！', '1549639862', '2130706433', '/addons/database/export/isadmin/1.html?id=19&start=0');
INSERT INTO `yzn_adminlog` VALUES ('257', '1', '1', '提示语:备份完成！', '1549639862', '2130706433', '/addons/database/export/isadmin/1.html?id=20&start=0');
INSERT INTO `yzn_adminlog` VALUES ('258', '1', '1', '提示语:备份完成！', '1549639862', '2130706433', '/addons/database/export/isadmin/1.html?id=21&start=0');
INSERT INTO `yzn_adminlog` VALUES ('259', '1', '1', '提示语:备份完成！', '1549639863', '2130706433', '/addons/database/export/isadmin/1.html?id=22&start=0');
INSERT INTO `yzn_adminlog` VALUES ('260', '1', '1', '提示语:备份完成！', '1549639863', '2130706433', '/addons/database/export/isadmin/1.html?id=23&start=0');
INSERT INTO `yzn_adminlog` VALUES ('261', '1', '1', '提示语:字段删除成功！', '1549639933', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('262', '1', '1', '提示语:设置成功！', '1549639973', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('263', '1', '1', '提示语:设置成功！', '1549639982', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('264', '1', '1', '提示语:设置成功！', '1549639994', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('265', '1', '1', '提示语:设置成功！', '1549639997', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('266', '1', '1', '提示语:设置成功！', '1549639998', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('267', '1', '1', '提示语:字段删除成功！', '1549640002', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('268', '1', '1', '提示语:字段删除成功！', '1549640006', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('269', '1', '1', '提示语:新增成功', '1549640092', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('270', '1', '1', '提示语:菜单排序成功！', '1549640102', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('271', '1', '1', '提示语:新增成功', '1549640155', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('272', '1', '1', '提示语:菜单排序成功！', '1549640163', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('273', '1', '1', '提示语:新增成功', '1549640190', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('274', '1', '1', '提示语:菜单排序成功！', '1549640197', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('275', '1', '1', '提示语:字段删除成功！', '1549640286', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('276', '1', '1', '提示语:字段删除成功！', '1549640321', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('277', '1', '1', '提示语:菜单排序成功！', '1549640327', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('278', '1', '1', '提示语:删除成功！', '1549640394', '2130706433', '/cms/cms/delete/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('279', '1', '1', '提示语:初始化成功！', '1549640423', '2130706433', '/addons/database/export/isadmin/1.html');
INSERT INTO `yzn_adminlog` VALUES ('280', '1', '1', '提示语:备份完成！', '1549640423', '2130706433', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `yzn_adminlog` VALUES ('281', '1', '1', '提示语:备份完成！', '1549640423', '2130706433', '/addons/database/export/isadmin/1.html?id=1&start=0');
INSERT INTO `yzn_adminlog` VALUES ('282', '1', '1', '提示语:备份完成！', '1549640423', '2130706433', '/addons/database/export/isadmin/1.html?id=2&start=0');
INSERT INTO `yzn_adminlog` VALUES ('283', '1', '1', '提示语:备份完成！', '1549640424', '2130706433', '/addons/database/export/isadmin/1.html?id=3&start=0');
INSERT INTO `yzn_adminlog` VALUES ('284', '1', '1', '提示语:备份完成！', '1549640424', '2130706433', '/addons/database/export/isadmin/1.html?id=4&start=0');
INSERT INTO `yzn_adminlog` VALUES ('285', '1', '1', '提示语:备份完成！', '1549640424', '2130706433', '/addons/database/export/isadmin/1.html?id=5&start=0');
INSERT INTO `yzn_adminlog` VALUES ('286', '1', '1', '提示语:备份完成！', '1549640424', '2130706433', '/addons/database/export/isadmin/1.html?id=6&start=0');
INSERT INTO `yzn_adminlog` VALUES ('287', '1', '1', '提示语:备份完成！', '1549640424', '2130706433', '/addons/database/export/isadmin/1.html?id=7&start=0');
INSERT INTO `yzn_adminlog` VALUES ('288', '1', '1', '提示语:备份完成！', '1549640425', '2130706433', '/addons/database/export/isadmin/1.html?id=8&start=0');
INSERT INTO `yzn_adminlog` VALUES ('289', '1', '1', '提示语:备份完成！', '1549640425', '2130706433', '/addons/database/export/isadmin/1.html?id=9&start=0');
INSERT INTO `yzn_adminlog` VALUES ('290', '1', '1', '提示语:备份完成！', '1549640425', '2130706433', '/addons/database/export/isadmin/1.html?id=10&start=0');
INSERT INTO `yzn_adminlog` VALUES ('291', '1', '1', '提示语:备份完成！', '1549640425', '2130706433', '/addons/database/export/isadmin/1.html?id=11&start=0');
INSERT INTO `yzn_adminlog` VALUES ('292', '1', '1', '提示语:备份完成！', '1549640425', '2130706433', '/addons/database/export/isadmin/1.html?id=12&start=0');
INSERT INTO `yzn_adminlog` VALUES ('293', '1', '1', '提示语:备份完成！', '1549640426', '2130706433', '/addons/database/export/isadmin/1.html?id=13&start=0');
INSERT INTO `yzn_adminlog` VALUES ('294', '1', '1', '提示语:备份完成！', '1549640426', '2130706433', '/addons/database/export/isadmin/1.html?id=14&start=0');
INSERT INTO `yzn_adminlog` VALUES ('295', '1', '1', '提示语:备份完成！', '1549640426', '2130706433', '/addons/database/export/isadmin/1.html?id=15&start=0');
INSERT INTO `yzn_adminlog` VALUES ('296', '1', '1', '提示语:备份完成！', '1549640426', '2130706433', '/addons/database/export/isadmin/1.html?id=16&start=0');
INSERT INTO `yzn_adminlog` VALUES ('297', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=17&start=0');
INSERT INTO `yzn_adminlog` VALUES ('298', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=18&start=0');
INSERT INTO `yzn_adminlog` VALUES ('299', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=19&start=0');
INSERT INTO `yzn_adminlog` VALUES ('300', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=20&start=0');
INSERT INTO `yzn_adminlog` VALUES ('301', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=21&start=0');
INSERT INTO `yzn_adminlog` VALUES ('302', '1', '1', '提示语:备份完成！', '1549640427', '2130706433', '/addons/database/export/isadmin/1.html?id=22&start=0');
INSERT INTO `yzn_adminlog` VALUES ('303', '1', '1', '提示语:备份完成！', '1549640428', '2130706433', '/addons/database/export/isadmin/1.html?id=23&start=0');
INSERT INTO `yzn_adminlog` VALUES ('304', '0', '0', '提示语:请先登陆', '1549681019', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('305', '0', '0', '提示语:密码错误！', '1549681049', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('306', '1', '1', '提示语:恭喜您，登陆成功', '1549681063', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('307', '1', '1', '提示语:删除成功！', '1549681334', '2130706433', '/cms/cms/delete/catid/1.html');
INSERT INTO `yzn_adminlog` VALUES ('308', '1', '1', '提示语:添加模型成功！', '1549681515', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('309', '1', '1', '提示语:字段删除成功！', '1549681574', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('310', '1', '1', '提示语:字段删除成功！', '1549681579', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('311', '1', '1', '提示语:设置成功！', '1549681584', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('312', '1', '1', '提示语:设置成功！', '1549681586', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('313', '1', '1', '提示语:设置成功！', '1549681588', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('314', '1', '1', '提示语:设置成功！', '1549681589', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('315', '0', '0', '提示语:请先登陆', '1549702247', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('316', '1', '1', '提示语:恭喜您，登陆成功', '1549702263', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('317', '1', '1', '提示语:操作成功！', '1549702708', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('318', '1', '1', '提示语:操作成功！', '1549702709', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('319', '1', '1', '提示语:操作成功！', '1549703105', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('320', '1', '1', '提示语:操作成功！', '1549703106', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('321', '1', '1', '提示语:操作成功！', '1549703107', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('322', '1', '1', '提示语:操作成功！', '1549703109', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('323', '1', '1', '提示语:操作成功！', '1549703110', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('324', '1', '1', '提示语:操作成功！', '1549703112', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('325', '1', '1', '提示语:操作成功！', '1549703113', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('326', '1', '1', '提示语:操作成功！', '1549703115', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('327', '1', '1', '提示语:操作成功！', '1549703117', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('328', '1', '1', '提示语:操作成功！', '1549703118', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('329', '1', '1', '提示语:操作成功！', '1549703124', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('330', '1', '1', '提示语:操作成功！', '1549703125', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('331', '1', '1', '提示语:操作成功！', '1549703126', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('332', '1', '1', '提示语:操作成功！', '1549703127', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('333', '1', '1', '提示语:操作成功！', '1549703171', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('334', '1', '1', '提示语:操作成功！', '1549703172', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('335', '1', '1', '提示语:操作成功！', '1549703172', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('336', '1', '1', '提示语:操作成功！', '1549703173', '2130706433', '/admin/config/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('337', '1', '1', '提示语:清理缓存', '1549703715', '2130706433', '/admin/index/cache.html?type=all&_=1549703681059');
INSERT INTO `yzn_adminlog` VALUES ('338', '1', '1', '提示语:添加成功！', '1549706054', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('339', '1', '1', '提示语:添加成功！', '1549706147', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('340', '1', '1', '提示语:添加成功！', '1549706344', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('341', '1', '1', '提示语:修改成功！', '1549707496', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('342', '1', '1', '提示语:修改成功！', '1549707705', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('343', '1', '1', '提示语:操作成功！', '1549714609', '2130706433', '/cms/category/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('344', '1', '1', '提示语:操作成功！', '1549714611', '2130706433', '/cms/category/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('345', '1', '1', '提示语:清理缓存', '1549714912', '2130706433', '/admin/index/cache.html?type=all&_=1549714888291');
INSERT INTO `yzn_adminlog` VALUES ('346', '1', '1', '提示语:清理缓存', '1549715242', '2130706433', '/admin/index/cache.html?type=all&_=1549715199787');
INSERT INTO `yzn_adminlog` VALUES ('347', '1', '1', '提示语:清理缓存', '1549715270', '2130706433', '/admin/index/cache.html?type=all&_=1549715266850');
INSERT INTO `yzn_adminlog` VALUES ('348', '1', '1', '提示语:清理缓存', '1549716216', '2130706433', '/admin/index/cache.html?type=all&_=1549716207682');
INSERT INTO `yzn_adminlog` VALUES ('349', '1', '1', '提示语:修改成功！', '1549716713', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('350', '0', '0', '提示语:请先登陆', '1549718240', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('351', '1', '1', '提示语:恭喜您，登陆成功', '1549718249', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('352', '0', '0', '提示语:请先登陆', '1549725618', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('353', '1', '1', '提示语:恭喜您，登陆成功', '1549725632', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('354', '1', '1', '提示语:修改成功！', '1549727208', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('355', '1', '1', '提示语:字段删除成功！', '1549727761', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('356', '1', '1', '提示语:清理缓存', '1549727768', '2130706433', '/admin/index/cache.html?type=all&_=1549727767484');
INSERT INTO `yzn_adminlog` VALUES ('357', '1', '1', '提示语:操作成功！', '1549728217', '2130706433', '/cms/cms/add/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('358', '1', '1', '提示语:操作成功！', '1549728222', '2130706433', '/cms/cms/add/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('359', '1', '1', '提示语:操作成功！', '1549728227', '2130706433', '/cms/cms/add/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('360', '1', '1', '提示语:操作成功！', '1549728236', '2130706433', '/cms/cms/add/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('361', '1', '1', '提示语:清理缓存', '1549729290', '2130706433', '/admin/index/cache.html?type=all&_=1549729281885');
INSERT INTO `yzn_adminlog` VALUES ('362', '1', '1', '提示语:清理缓存', '1549731816', '2130706433', '/admin/index/cache.html?type=all&_=1549731723836');
INSERT INTO `yzn_adminlog` VALUES ('363', '1', '1', '提示语:清理缓存', '1549731843', '2130706433', '/admin/index/cache.html?type=all&_=1549731819208');
INSERT INTO `yzn_adminlog` VALUES ('364', '1', '1', '提示语:清理缓存', '1549732162', '2130706433', '/admin/index/cache.html?type=all&_=1549731953431');
INSERT INTO `yzn_adminlog` VALUES ('365', '0', '0', '提示语:请先登陆', '1549765103', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('366', '1', '1', '提示语:恭喜您，登陆成功', '1549765119', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('367', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765739', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('368', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765765', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('369', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765786', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('370', '1', '1', '提示语:清理缓存', '1549765877', '2130706433', '/admin/index/cache.html?type=all&_=1549765121026');
INSERT INTO `yzn_adminlog` VALUES ('371', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765900', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('372', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765913', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('373', '0', '1', '提示语:SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name \'title\'', '1549765923', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('374', '1', '1', '提示语:添加模型成功！', '1549766005', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('375', '1', '1', '提示语:添加成功！', '1549766051', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('376', '1', '1', '提示语:操作成功！', '1549766096', '2130706433', '/cms/cms/add/catid/7.html');
INSERT INTO `yzn_adminlog` VALUES ('377', '1', '1', '提示语:删除成功！', '1549766154', '2130706433', '/cms/cms/delete/catid/7.html');
INSERT INTO `yzn_adminlog` VALUES ('378', '1', '1', '提示语:栏目删除成功！', '1549766161', '2130706433', '/cms/category/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('379', '1', '1', '提示语:删除成功！', '1549766168', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('380', '1', '1', '提示语:操作成功！', '1549766560', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('381', '1', '1', '提示语:操作成功！', '1549766669', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('382', '1', '1', '提示语:删除成功！', '1549766735', '2130706433', '/cms/cms/delete/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('383', '1', '1', '提示语:删除成功！', '1549766739', '2130706433', '/cms/cms/delete/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('384', '0', '1', '提示语:fields not exists:[relationid]', '1549766753', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('385', '1', '1', '提示语:操作成功！', '1549766787', '2130706433', '/cms/cms/add/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('386', '1', '1', '提示语:添加模型成功！', '1549769119', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('387', '1', '1', '提示语:删除成功！', '1549769532', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('388', '1', '1', '提示语:添加模型成功！', '1549769548', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('389', '1', '1', '提示语:删除成功！', '1549769677', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('390', '1', '1', '提示语:删除成功！', '1549769836', '2130706433', '/cms/cms/delete/catid/3.html');
INSERT INTO `yzn_adminlog` VALUES ('391', '1', '1', '提示语:删除成功！', '1549769849', '2130706433', '/cms/cms/delete/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('392', '1', '1', '提示语:删除成功！', '1549769854', '2130706433', '/cms/cms/delete/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('393', '1', '1', '提示语:删除成功！', '1549769857', '2130706433', '/cms/cms/delete/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('394', '1', '1', '提示语:删除成功！', '1549769861', '2130706433', '/cms/cms/delete/catid/6.html');
INSERT INTO `yzn_adminlog` VALUES ('395', '0', '1', '提示语:该模型使用中，删除栏目后再删除！', '1549769868', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('396', '0', '1', '提示语:该模型使用中，删除栏目后再删除！', '1549769873', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('397', '1', '1', '提示语:栏目删除成功！', '1549769880', '2130706433', '/cms/category/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('398', '1', '1', '提示语:栏目删除成功！', '1549769885', '2130706433', '/cms/category/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('399', '1', '1', '提示语:栏目删除成功！', '1549769888', '2130706433', '/cms/category/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('400', '1', '1', '提示语:栏目删除成功！', '1549769892', '2130706433', '/cms/category/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('401', '1', '1', '提示语:删除成功！', '1549769898', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('402', '1', '1', '提示语:删除成功！', '1549769902', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('403', '1', '1', '提示语:删除成功！', '1549769906', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('404', '1', '1', '提示语:删除成功！', '1549769910', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('405', '1', '1', '提示语:添加模型成功！', '1549770624', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('406', '1', '1', '提示语:添加模型成功！', '1549770672', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('407', '1', '1', '提示语:字段删除成功！', '1549770691', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('408', '1', '1', '提示语:字段删除成功！', '1549770696', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('409', '1', '1', '提示语:设置成功！', '1549770701', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('410', '1', '1', '提示语:设置成功！', '1549770702', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('411', '0', '1', '提示语:必填字段不可以设置为隐藏！', '1549770713', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('412', '0', '1', '提示语:必填字段不可以设置为隐藏！', '1549770722', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('413', '0', '1', '提示语:必填字段不可以设置为隐藏！', '1549770740', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('414', '1', '1', '提示语:删除成功！', '1549770778', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('415', '1', '1', '提示语:添加模型成功！', '1549770803', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('416', '1', '1', '提示语:字段删除成功！', '1549770812', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('417', '1', '1', '提示语:字段删除成功！', '1549770816', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('418', '1', '1', '提示语:设置成功！', '1549770821', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('419', '1', '1', '提示语:设置成功！', '1549770824', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('420', '1', '1', '提示语:设置成功！', '1549770825', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('421', '1', '1', '提示语:设置成功！', '1549770827', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('422', '1', '1', '提示语:设置成功！', '1549770830', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('423', '0', '1', '提示语:唯一标识为纯字母', '1549770890', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('424', '1', '1', '提示语:添加成功！', '1549770963', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('425', '1', '1', '提示语:添加成功！', '1549770993', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('426', '1', '1', '提示语:操作成功！', '1549771014', '2130706433', '/cms/cms/add/catid/8.html');
INSERT INTO `yzn_adminlog` VALUES ('427', '1', '1', '提示语:操作成功！', '1549771018', '2130706433', '/cms/cms/add/catid/8.html');
INSERT INTO `yzn_adminlog` VALUES ('428', '1', '1', '提示语:操作成功！', '1549771025', '2130706433', '/cms/cms/add/catid/8.html');
INSERT INTO `yzn_adminlog` VALUES ('429', '1', '1', '提示语:操作成功！', '1549771334', '2130706433', '/cms/cms/add/catid/9.html');
INSERT INTO `yzn_adminlog` VALUES ('430', '1', '1', '提示语:清理缓存', '1549771527', '2130706433', '/admin/index/cache.html?type=all&_=1549771307804');
INSERT INTO `yzn_adminlog` VALUES ('431', '1', '1', '提示语:编辑成功！', '1549771811', '2130706433', '/cms/cms/edit/catid/9.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('432', '1', '1', '提示语:删除成功！', '1549774424', '2130706433', '/cms/cms/delete/catid/9.html');
INSERT INTO `yzn_adminlog` VALUES ('433', '1', '1', '提示语:更新成功！', '1549774958', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('434', '1', '1', '提示语:更新成功！', '1549774998', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('435', '1', '1', '提示语:更新成功！', '1549775050', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('436', '1', '1', '提示语:初始化成功！', '1549775157', '2130706433', '/addons/database/export/isadmin/1.html');
INSERT INTO `yzn_adminlog` VALUES ('437', '1', '1', '提示语:备份完成！', '1549775157', '2130706433', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `yzn_adminlog` VALUES ('438', '1', '1', '提示语:备份完成！', '1549775158', '2130706433', '/addons/database/export/isadmin/1.html?id=1&start=0');
INSERT INTO `yzn_adminlog` VALUES ('439', '1', '1', '提示语:备份完成！', '1549775158', '2130706433', '/addons/database/export/isadmin/1.html?id=2&start=0');
INSERT INTO `yzn_adminlog` VALUES ('440', '1', '1', '提示语:备份完成！', '1549775158', '2130706433', '/addons/database/export/isadmin/1.html?id=3&start=0');
INSERT INTO `yzn_adminlog` VALUES ('441', '1', '1', '提示语:备份完成！', '1549775159', '2130706433', '/addons/database/export/isadmin/1.html?id=4&start=0');
INSERT INTO `yzn_adminlog` VALUES ('442', '1', '1', '提示语:备份完成！', '1549775159', '2130706433', '/addons/database/export/isadmin/1.html?id=5&start=0');
INSERT INTO `yzn_adminlog` VALUES ('443', '1', '1', '提示语:备份完成！', '1549775159', '2130706433', '/addons/database/export/isadmin/1.html?id=6&start=0');
INSERT INTO `yzn_adminlog` VALUES ('444', '1', '1', '提示语:备份完成！', '1549775159', '2130706433', '/addons/database/export/isadmin/1.html?id=7&start=0');
INSERT INTO `yzn_adminlog` VALUES ('445', '1', '1', '提示语:备份完成！', '1549775160', '2130706433', '/addons/database/export/isadmin/1.html?id=8&start=0');
INSERT INTO `yzn_adminlog` VALUES ('446', '1', '1', '提示语:备份完成！', '1549775160', '2130706433', '/addons/database/export/isadmin/1.html?id=9&start=0');
INSERT INTO `yzn_adminlog` VALUES ('447', '1', '1', '提示语:备份完成！', '1549775160', '2130706433', '/addons/database/export/isadmin/1.html?id=10&start=0');
INSERT INTO `yzn_adminlog` VALUES ('448', '1', '1', '提示语:备份完成！', '1549775160', '2130706433', '/addons/database/export/isadmin/1.html?id=11&start=0');
INSERT INTO `yzn_adminlog` VALUES ('449', '1', '1', '提示语:备份完成！', '1549775161', '2130706433', '/addons/database/export/isadmin/1.html?id=12&start=0');
INSERT INTO `yzn_adminlog` VALUES ('450', '1', '1', '提示语:备份完成！', '1549775161', '2130706433', '/addons/database/export/isadmin/1.html?id=13&start=0');
INSERT INTO `yzn_adminlog` VALUES ('451', '1', '1', '提示语:备份完成！', '1549775161', '2130706433', '/addons/database/export/isadmin/1.html?id=14&start=0');
INSERT INTO `yzn_adminlog` VALUES ('452', '1', '1', '提示语:备份完成！', '1549775161', '2130706433', '/addons/database/export/isadmin/1.html?id=15&start=0');
INSERT INTO `yzn_adminlog` VALUES ('453', '1', '1', '提示语:备份完成！', '1549775162', '2130706433', '/addons/database/export/isadmin/1.html?id=16&start=0');
INSERT INTO `yzn_adminlog` VALUES ('454', '1', '1', '提示语:备份完成！', '1549775162', '2130706433', '/addons/database/export/isadmin/1.html?id=17&start=0');
INSERT INTO `yzn_adminlog` VALUES ('455', '1', '1', '提示语:备份完成！', '1549775162', '2130706433', '/addons/database/export/isadmin/1.html?id=18&start=0');
INSERT INTO `yzn_adminlog` VALUES ('456', '1', '1', '提示语:备份完成！', '1549775162', '2130706433', '/addons/database/export/isadmin/1.html?id=19&start=0');
INSERT INTO `yzn_adminlog` VALUES ('457', '1', '1', '提示语:备份完成！', '1549775163', '2130706433', '/addons/database/export/isadmin/1.html?id=20&start=0');
INSERT INTO `yzn_adminlog` VALUES ('458', '1', '1', '提示语:字段删除成功！', '1549775635', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('459', '0', '1', '提示语:字段名称只能为字母和数字', '1549775667', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('460', '1', '1', '提示语:新增成功', '1549775686', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('461', '1', '1', '提示语:菜单排序成功！', '1549775702', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('462', '1', '1', '提示语:添加模型成功！', '1549775818', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('463', '1', '1', '提示语:添加模型成功！', '1549775861', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('464', '1', '1', '提示语:字段删除成功！', '1549775901', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('465', '1', '1', '提示语:字段删除成功！', '1549775906', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('466', '1', '1', '提示语:字段删除成功！', '1549775914', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('467', '1', '1', '提示语:新增成功', '1549775937', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('468', '1', '1', '提示语:菜单排序成功！', '1549775944', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('469', '1', '1', '提示语:设置成功！', '1549775951', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('470', '1', '1', '提示语:设置成功！', '1549775954', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('471', '1', '1', '提示语:新增成功', '1549775998', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('472', '1', '1', '提示语:菜单排序成功！', '1549776006', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('473', '1', '1', '提示语:菜单排序成功！', '1549776008', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('474', '1', '1', '提示语:添加成功！', '1549776156', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('475', '1', '1', '提示语:添加成功！', '1549776208', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('476', '1', '1', '提示语:添加成功！', '1549776272', '2130706433', '/cms/category/add.html');
INSERT INTO `yzn_adminlog` VALUES ('477', '1', '1', '提示语:操作成功！', '1549776328', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('478', '0', '1', '提示语:\'语法\'必须填写~', '1549776934', '2130706433', '/cms/cms/add/catid/12.html');
INSERT INTO `yzn_adminlog` VALUES ('479', '1', '1', '提示语:操作成功！', '1549776954', '2130706433', '/cms/cms/add/catid/11.html');
INSERT INTO `yzn_adminlog` VALUES ('480', '0', '1', '提示语:\'语法\'必须填写~', '1549776972', '2130706433', '/cms/cms/add/catid/12.html');
INSERT INTO `yzn_adminlog` VALUES ('481', '1', '1', '提示语:删除成功！', '1549777002', '2130706433', '/cms/cms/delete/catid/11.html');
INSERT INTO `yzn_adminlog` VALUES ('482', '1', '1', '提示语:操作成功！', '1549777017', '2130706433', '/cms/cms/add/catid/12.html');
INSERT INTO `yzn_adminlog` VALUES ('483', '1', '1', '提示语:操作成功！', '1549777034', '2130706433', '/cms/cms/add/catid/11.html');
INSERT INTO `yzn_adminlog` VALUES ('484', '1', '1', '提示语:编辑成功！', '1549777045', '2130706433', '/cms/cms/edit/catid/12.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('485', '1', '1', '提示语:编辑成功！', '1549777060', '2130706433', '/cms/cms/edit/catid/12.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('486', '0', '0', '提示语:请先登陆', '1549895782', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('487', '1', '1', '提示语:恭喜您，登陆成功', '1549895799', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('488', '1', '1', '提示语:设置成功！', '1549895886', '2130706433', '/cms/field/setrequire.html');
INSERT INTO `yzn_adminlog` VALUES ('489', '1', '1', '提示语:修改成功！', '1549896007', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('490', '1', '1', '提示语:删除成功！', '1549896013', '2130706433', '/cms/models/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('491', '1', '1', '提示语:模型修改成功！', '1549896035', '2130706433', '/cms/models/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('492', '1', '1', '提示语:设置成功！', '1549896127', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('493', '1', '1', '提示语:设置成功！', '1549896131', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('494', '1', '1', '提示语:菜单排序成功！', '1549896193', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('495', '1', '1', '提示语:菜单排序成功！', '1549896197', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('496', '1', '1', '提示语:菜单排序成功！', '1549897393', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('497', '1', '1', '提示语:菜单排序成功！', '1549897406', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('498', '1', '1', '提示语:菜单排序成功！', '1549897409', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('499', '1', '1', '提示语:菜单排序成功！', '1549897411', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('500', '1', '1', '提示语:菜单排序成功！', '1549897415', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('501', '1', '1', '提示语:菜单排序成功！', '1549897418', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('502', '1', '1', '提示语:菜单排序成功！', '1549897421', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('503', '1', '1', '提示语:更新成功！', '1549897490', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('504', '1', '1', '提示语:字段删除成功！', '1549897529', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('505', '1', '1', '提示语:新增成功', '1549897557', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('506', '1', '1', '提示语:菜单排序成功！', '1549897594', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('507', '1', '1', '提示语:菜单排序成功！', '1549897601', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('508', '1', '1', '提示语:菜单排序成功！', '1549897605', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('509', '1', '1', '提示语:菜单排序成功！', '1549897608', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('510', '1', '1', '提示语:菜单排序成功！', '1549897613', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('511', '1', '1', '提示语:菜单排序成功！', '1549897617', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('512', '1', '1', '提示语:菜单排序成功！', '1549897619', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('513', '1', '1', '提示语:菜单排序成功！', '1549897623', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('514', '1', '1', '提示语:操作成功！', '1549898655', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('515', '1', '1', '提示语:更新成功！', '1549898675', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('516', '1', '1', '提示语:操作成功！', '1549898681', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('517', '1', '1', '提示语:菜单排序成功！', '1549898690', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('518', '1', '1', '提示语:菜单排序成功！', '1549898697', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('519', '1', '1', '提示语:更新成功！', '1549898745', '2130706433', '/cms/field/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('520', '1', '1', '提示语:操作成功！', '1549898748', '2130706433', '/cms/field/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('521', '1', '1', '提示语:编辑成功！', '1549898877', '2130706433', '/cms/cms/edit/catid/8.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('522', '1', '1', '提示语:编辑成功！', '1549898896', '2130706433', '/cms/cms/edit/catid/8.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('523', '0', '0', '提示语:请先登陆', '1549969186', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('524', '1', '1', '提示语:恭喜您，登陆成功', '1549969199', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('525', '1', '1', '提示语:修改成功！', '1549970525', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('526', '1', '1', '提示语:修改成功！', '1549970554', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('527', '1', '1', '提示语:修改成功！', '1549970630', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('528', '1', '1', '提示语:清理缓存', '1549970828', '2130706433', '/admin/index/cache.html?type=all&_=1549970123208');
INSERT INTO `yzn_adminlog` VALUES ('529', '1', '1', '提示语:清理缓存', '1549970850', '2130706433', '/admin/index/cache.html?type=all&_=1549970123209');
INSERT INTO `yzn_adminlog` VALUES ('530', '1', '1', '提示语:清理缓存', '1549971034', '2130706433', '/admin/index/cache.html?type=all&_=1549970891399');
INSERT INTO `yzn_adminlog` VALUES ('531', '1', '1', '提示语:清理缓存', '1549971398', '2130706433', '/admin/index/cache.html?type=all&_=1549971036257');
INSERT INTO `yzn_adminlog` VALUES ('532', '1', '1', '提示语:清理缓存', '1549971449', '2130706433', '/admin/index/cache.html?type=all&_=1549971416492');
INSERT INTO `yzn_adminlog` VALUES ('533', '1', '1', '提示语:清理缓存', '1549971696', '2130706433', '/admin/index/cache.html?type=all&_=1549971416494');
INSERT INTO `yzn_adminlog` VALUES ('534', '1', '1', '提示语:清理缓存', '1549971770', '2130706433', '/admin/index/cache.html?type=all&_=1549971744827');
INSERT INTO `yzn_adminlog` VALUES ('535', '0', '0', '提示语:请先登陆', '1549978239', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('536', '1', '1', '提示语:恭喜您，登陆成功', '1549978253', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('537', '0', '0', '提示语:请先登陆', '1550058040', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('538', '1', '1', '提示语:恭喜您，登陆成功', '1550058062', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('539', '1', '1', '提示语:清理缓存', '1550058831', '2130706433', '/admin/index/cache.html?type=all&_=1550058064262');
INSERT INTO `yzn_adminlog` VALUES ('540', '0', '1', '提示语:\'扩展\'必须填写~', '1550059364', '2130706433', '/cms/cms/add/catid/9.html');
INSERT INTO `yzn_adminlog` VALUES ('541', '1', '1', '提示语:操作成功！', '1550059368', '2130706433', '/cms/cms/add/catid/9.html');
INSERT INTO `yzn_adminlog` VALUES ('542', '1', '1', '提示语:操作成功！', '1550060264', '2130706433', '/cms/category/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('543', '1', '1', '提示语:操作成功！', '1550060265', '2130706433', '/cms/category/setstate.html');
INSERT INTO `yzn_adminlog` VALUES ('544', '1', '1', '提示语:修改成功！', '1550060626', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('545', '1', '1', '提示语:编辑成功！', '1550060640', '2130706433', '/cms/cms/edit/catid/9.html?id=2');
INSERT INTO `yzn_adminlog` VALUES ('546', '1', '1', '提示语:编辑成功！', '1550060734', '2130706433', '/cms/cms/edit/catid/9.html?id=2');
INSERT INTO `yzn_adminlog` VALUES ('547', '0', '0', '提示语:请先登陆', '1550144748', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('548', '1', '1', '提示语:恭喜您，登陆成功', '1550144759', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('549', '1', '1', '提示语:清理缓存', '1550145608', '2130706433', '/admin/index/cache.html?type=all&_=1550144761069');
INSERT INTO `yzn_adminlog` VALUES ('550', '1', '1', '提示语:操作成功！', '1550146872', '2130706433', '/cms/cms/add/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('551', '1', '1', '提示语:清理缓存', '1550146959', '2130706433', '/admin/index/cache.html?type=all&_=1550144761070');
INSERT INTO `yzn_adminlog` VALUES ('552', '1', '1', '提示语:清理缓存', '1550147691', '2130706433', '/admin/index/cache.html?type=all&_=1550144761071');
INSERT INTO `yzn_adminlog` VALUES ('553', '1', '1', '提示语:编辑成功！', '1550147747', '2130706433', '/cms/cms/edit/catid/10.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('554', '1', '1', '提示语:编辑成功！', '1550147870', '2130706433', '/cms/cms/edit/catid/10.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('555', '0', '0', '提示语:请先登陆', '1550238295', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('556', '1', '1', '提示语:恭喜您，登陆成功', '1550238308', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('557', '1', '1', '提示语:模型修改成功！', '1550245015', '2130706433', '/cms/models/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('558', '1', '1', '提示语:添加模型成功！', '1550245049', '2130706433', '/cms/models/add.html');
INSERT INTO `yzn_adminlog` VALUES ('559', '1', '1', '提示语:字段删除成功！', '1550245068', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('560', '1', '1', '提示语:字段删除成功！', '1550245074', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('561', '1', '1', '提示语:字段删除成功！', '1550245080', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('562', '1', '1', '提示语:设置成功！', '1550245084', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('563', '1', '1', '提示语:设置成功！', '1550245087', '2130706433', '/cms/field/setvisible.html');
INSERT INTO `yzn_adminlog` VALUES ('564', '1', '1', '提示语:新增成功', '1550245122', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('565', '1', '1', '提示语:菜单排序成功！', '1550245132', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('566', '1', '1', '提示语:修改成功！', '1550245150', '2130706433', '/cms/category/edit.html');
INSERT INTO `yzn_adminlog` VALUES ('567', '1', '1', '提示语:菜单排序成功！', '1550245186', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('568', '1', '1', '提示语:菜单排序成功！', '1550245188', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('569', '1', '1', '提示语:菜单排序成功！', '1550245189', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('570', '1', '1', '提示语:菜单排序成功！', '1550245191', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('571', '1', '1', '提示语:菜单排序成功！', '1550245195', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('572', '0', '0', '提示语:请先登陆', '1550321843', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('573', '1', '1', '提示语:恭喜您，登陆成功', '1550321861', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('574', '1', '1', '提示语:清理缓存', '1550323117', '2130706433', '/admin/index/cache.html?type=all&_=1550321862789');
INSERT INTO `yzn_adminlog` VALUES ('575', '1', '1', '提示语:初始化成功！', '1550329311', '2130706433', '/addons/database/export/isadmin/1.html');
INSERT INTO `yzn_adminlog` VALUES ('576', '1', '1', '提示语:备份完成！', '1550329311', '2130706433', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `yzn_adminlog` VALUES ('577', '1', '1', '提示语:备份完成！', '1550329311', '2130706433', '/addons/database/export/isadmin/1.html?id=1&start=0');
INSERT INTO `yzn_adminlog` VALUES ('578', '1', '1', '提示语:备份完成！', '1550329312', '2130706433', '/addons/database/export/isadmin/1.html?id=2&start=0');
INSERT INTO `yzn_adminlog` VALUES ('579', '1', '1', '提示语:备份完成！', '1550329312', '2130706433', '/addons/database/export/isadmin/1.html?id=3&start=0');
INSERT INTO `yzn_adminlog` VALUES ('580', '1', '1', '提示语:备份完成！', '1550329312', '2130706433', '/addons/database/export/isadmin/1.html?id=4&start=0');
INSERT INTO `yzn_adminlog` VALUES ('581', '1', '1', '提示语:备份完成！', '1550329312', '2130706433', '/addons/database/export/isadmin/1.html?id=5&start=0');
INSERT INTO `yzn_adminlog` VALUES ('582', '1', '1', '提示语:备份完成！', '1550329312', '2130706433', '/addons/database/export/isadmin/1.html?id=6&start=0');
INSERT INTO `yzn_adminlog` VALUES ('583', '1', '1', '提示语:备份完成！', '1550329313', '2130706433', '/addons/database/export/isadmin/1.html?id=7&start=0');
INSERT INTO `yzn_adminlog` VALUES ('584', '1', '1', '提示语:备份完成！', '1550329313', '2130706433', '/addons/database/export/isadmin/1.html?id=8&start=0');
INSERT INTO `yzn_adminlog` VALUES ('585', '1', '1', '提示语:备份完成！', '1550329313', '2130706433', '/addons/database/export/isadmin/1.html?id=9&start=0');
INSERT INTO `yzn_adminlog` VALUES ('586', '1', '1', '提示语:备份完成！', '1550329314', '2130706433', '/addons/database/export/isadmin/1.html?id=10&start=0');
INSERT INTO `yzn_adminlog` VALUES ('587', '1', '1', '提示语:备份完成！', '1550329314', '2130706433', '/addons/database/export/isadmin/1.html?id=11&start=0');
INSERT INTO `yzn_adminlog` VALUES ('588', '1', '1', '提示语:备份完成！', '1550329314', '2130706433', '/addons/database/export/isadmin/1.html?id=12&start=0');
INSERT INTO `yzn_adminlog` VALUES ('589', '1', '1', '提示语:备份完成！', '1550329315', '2130706433', '/addons/database/export/isadmin/1.html?id=13&start=0');
INSERT INTO `yzn_adminlog` VALUES ('590', '1', '1', '提示语:备份完成！', '1550329315', '2130706433', '/addons/database/export/isadmin/1.html?id=14&start=0');
INSERT INTO `yzn_adminlog` VALUES ('591', '1', '1', '提示语:备份完成！', '1550329315', '2130706433', '/addons/database/export/isadmin/1.html?id=15&start=0');
INSERT INTO `yzn_adminlog` VALUES ('592', '1', '1', '提示语:备份完成！', '1550329315', '2130706433', '/addons/database/export/isadmin/1.html?id=16&start=0');
INSERT INTO `yzn_adminlog` VALUES ('593', '1', '1', '提示语:备份完成！', '1550329316', '2130706433', '/addons/database/export/isadmin/1.html?id=17&start=0');
INSERT INTO `yzn_adminlog` VALUES ('594', '1', '1', '提示语:备份完成！', '1550329316', '2130706433', '/addons/database/export/isadmin/1.html?id=18&start=0');
INSERT INTO `yzn_adminlog` VALUES ('595', '1', '1', '提示语:备份完成！', '1550329316', '2130706433', '/addons/database/export/isadmin/1.html?id=19&start=0');
INSERT INTO `yzn_adminlog` VALUES ('596', '1', '1', '提示语:备份完成！', '1550329316', '2130706433', '/addons/database/export/isadmin/1.html?id=20&start=0');
INSERT INTO `yzn_adminlog` VALUES ('597', '1', '1', '提示语:备份完成！', '1550329316', '2130706433', '/addons/database/export/isadmin/1.html?id=21&start=0');
INSERT INTO `yzn_adminlog` VALUES ('598', '1', '1', '提示语:备份完成！', '1550329317', '2130706433', '/addons/database/export/isadmin/1.html?id=22&start=0');
INSERT INTO `yzn_adminlog` VALUES ('599', '1', '1', '提示语:备份完成！', '1550329317', '2130706433', '/addons/database/export/isadmin/1.html?id=23&start=0');
INSERT INTO `yzn_adminlog` VALUES ('600', '1', '1', '提示语:备份完成！', '1550329317', '2130706433', '/addons/database/export/isadmin/1.html?id=24&start=0');
INSERT INTO `yzn_adminlog` VALUES ('601', '0', '0', '提示语:请先登陆', '1550582442', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('602', '0', '0', '提示语:请先登陆', '1550582442', '2130706433', '/admin');
INSERT INTO `yzn_adminlog` VALUES ('603', '1', '1', '提示语:恭喜您，登陆成功', '1550582450', '2130706433', '/admin/index/login.html');
INSERT INTO `yzn_adminlog` VALUES ('604', '1', '1', '提示语:编辑成功！', '1550582506', '2130706433', '/cms/cms/edit/catid/10.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('605', '1', '1', '提示语:操作成功！', '1550582613', '2130706433', '/cms/cms/add/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('606', '1', '1', '提示语:删除成功！', '1550582719', '2130706433', '/cms/cms/delete/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('607', '1', '1', '提示语:编辑成功！', '1550582725', '2130706433', '/cms/cms/edit/catid/10.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('608', '1', '1', '提示语:编辑成功！', '1550585023', '2130706433', '/cms/cms/edit/catid/10.html?id=1');
INSERT INTO `yzn_adminlog` VALUES ('609', '1', '1', '提示语:操作成功！', '1550585033', '2130706433', '/cms/cms/add/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('610', '1', '1', '提示语:删除成功！', '1550585239', '2130706433', '/cms/cms/delete/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('611', '1', '1', '提示语:删除成功！', '1550585243', '2130706433', '/cms/cms/delete/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('612', '1', '1', '提示语:字段删除成功！', '1550585256', '2130706433', '/cms/field/delete.html');
INSERT INTO `yzn_adminlog` VALUES ('613', '1', '1', '提示语:新增成功', '1550585283', '2130706433', '/cms/field/add.html');
INSERT INTO `yzn_adminlog` VALUES ('614', '1', '1', '提示语:菜单排序成功！', '1550585293', '2130706433', '/cms/field/listorder.html');
INSERT INTO `yzn_adminlog` VALUES ('615', '1', '1', '提示语:操作成功！', '1550585920', '2130706433', '/cms/cms/add/catid/10.html');
INSERT INTO `yzn_adminlog` VALUES ('616', '1', '1', '提示语:编辑成功！', '1550586933', '2130706433', '/cms/cms/edit/catid/10.html?id=4');
INSERT INTO `yzn_adminlog` VALUES ('617', '1', '1', '提示语:编辑成功！', '1550587226', '2130706433', '/cms/cms/edit/catid/10.html?id=4');
INSERT INTO `yzn_adminlog` VALUES ('618', '1', '1', '提示语:编辑成功！', '1550588784', '2130706433', '/cms/cms/edit/catid/10.html?id=4');
INSERT INTO `yzn_adminlog` VALUES ('619', '1', '1', '提示语:编辑成功！', '1550588992', '2130706433', '/cms/cms/edit/catid/10.html?id=4');
INSERT INTO `yzn_adminlog` VALUES ('620', '1', '1', '提示语:编辑成功！', '1550589024', '2130706433', '/cms/cms/edit/catid/10.html?id=4');
INSERT INTO `yzn_adminlog` VALUES ('621', '1', '1', '提示语:初始化成功！', '1550590408', '2130706433', '/addons/database/export/isadmin/1.html');
INSERT INTO `yzn_adminlog` VALUES ('622', '1', '1', '提示语:备份完成！', '1550590409', '2130706433', '/addons/database/export/isadmin/1.html?id=0&start=0');
INSERT INTO `yzn_adminlog` VALUES ('623', '1', '1', '提示语:备份完成！', '1550590409', '2130706433', '/addons/database/export/isadmin/1.html?id=1&start=0');

-- -----------------------------
-- Table structure for `yzn_article`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_article`;
CREATE TABLE `yzn_article` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `relation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '扩展内容',
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `posid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `hits` mediumint(8) unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文章列表模型表';

-- -----------------------------
-- Records of `yzn_article`
-- -----------------------------
INSERT INTO `yzn_article` VALUES ('4', '10', '标题文章', '', '标题文章', '标题文章', '0', '100', '0', '0', '1550585880', '1550589024', '1');

-- -----------------------------
-- Table structure for `yzn_article_data`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_article_data`;
CREATE TABLE `yzn_article_data` (
  `did` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文章列表模型表';

-- -----------------------------
-- Records of `yzn_article_data`
-- -----------------------------
INSERT INTO `yzn_article_data` VALUES ('4', '<p>123</p><p><br/></p><p>abc</p><p>123abc</p><p><br/></p><p><br/></p><p><br/></p><p>标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章标题文章<img src=\"/uploads/images/20190219/739507a46baf61c8d57457968d063d53.jpg\" title=\"1.jpg\" alt=\"\"/></p>');

-- -----------------------------
-- Table structure for `yzn_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_attachment`;
CREATE TABLE `yzn_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` char(50) NOT NULL DEFAULT '' COMMENT '文件名',
  `module` char(15) NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(64) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` char(4) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorders` int(5) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- -----------------------------
-- Records of `yzn_attachment`
-- -----------------------------
INSERT INTO `yzn_attachment` VALUES ('1', '1', '22790d289d0a85d4efa3a8d8abb2d074.jpg', 'cms', 'images/20190120/f6e0bb792a17f537ff2d804ed54d1c29.jpg', '', '', 'image/jpeg', 'jpg', '95092', 'f1f7c125ffcbfe5df41e96b9546f9f90', '44c16d293c60abee6c45d89b0c2620d1face6ab1', 'local', '1547997724', '1547997724', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('2', '1', '1.jpg', 'cms', 'images/20190204/644abe59dfd2d97259b12db1cadb270f.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549292674', '1549292674', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('3', '1', '1.jpg', 'cms', 'images/20190204/431e3166ccc8100a9ee6ab0b06b29a80.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549293346', '1549293346', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('4', '1', '1.jpg', 'cms', 'images/20190204/e78ea0064239c485057d537267a21a67.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549293464', '1549293464', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('5', '1', '1.jpg', 'cms', 'images/20190204/73ec9c22293c07b78957b504d03ed5e2.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549293611', '1549293611', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('6', '1', '1.jpg', 'cms', 'images/20190204/c577f1390e9cc04cfaaf775bd9cb025f.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549293692', '1549293692', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('7', '1', '1.jpg', 'cms', 'images/20190204/454d30ee9cd1a65afa25109df7313804.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549293762', '1549293762', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('8', '1', '1.jpg', 'cms', 'images/20190204/538b9b274591ab858941a9818bdf7d31.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549294074', '1549294074', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('9', '1', '1.jpg', 'cms', 'images/20190204/e50f7217d07f02758b58b4c04f112fdb.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549294165', '1549294165', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('10', '1', '1.jpg', 'cms', 'images/20190205/f683ba0fb3a6d6794a923da8ce23ef40.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549338249', '1549338249', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('11', '1', '1.jpg', 'cms', 'images/20190205/f22f35632c74bc7ebbdc47c019a50b43.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549338313', '1549338313', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('12', '1', '1.jpg', 'cms', 'images/20190205/ceb432dc6e00acedcab4baea9a935c12.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549342777', '1549342777', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('13', '1', '1.jpg', 'cms', 'images/20190205/2968736bac1b2bbff9291367d4a792ac.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1549343159', '1549343159', '100', '1');
INSERT INTO `yzn_attachment` VALUES ('14', '1', '1.jpg', '', 'images/20190219/739507a46baf61c8d57457968d063d53.jpg', '', '', 'image/jpeg', 'jpg', '44305', '89b1d559aa03b9bef08e2036015201ff', '4d3b0d0baec5a1865b1142cc1cd1117593d63bf6', 'local', '1550585917', '1550585917', '100', '1');

-- -----------------------------
-- Table structure for `yzn_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_auth_group`;
CREATE TABLE `yzn_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='权限组表';

-- -----------------------------
-- Records of `yzn_auth_group`
-- -----------------------------
INSERT INTO `yzn_auth_group` VALUES ('1', 'admin', '1', '超级管理员', '拥有所有权限', '1', '154,155,146,149,149,158,159,160,150,151,161,162,163,157,164,165,152,152,153,156,147,148');
INSERT INTO `yzn_auth_group` VALUES ('2', 'admin', '1', '编辑', '编辑', '1', '179,195,198,180,180,197,199,200,181,182,186,187,188,196,189,190,183,183,184,185,201,201,201,201,202,202,202,192,193');

-- -----------------------------
-- Table structure for `yzn_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_auth_rule`;
CREATE TABLE `yzn_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=222 DEFAULT CHARSET=utf8 COMMENT='规则表';

-- -----------------------------
-- Records of `yzn_auth_rule`
-- -----------------------------
INSERT INTO `yzn_auth_rule` VALUES ('179', 'admin', '2', 'admin/index/index', '首页', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('180', 'admin', '1', 'admin/config/index', '配置管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('181', 'admin', '1', 'admin/config/setting', '网站设置', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('182', 'admin', '1', 'admin/menu/index', '菜单管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('183', 'admin', '1', 'admin/manager/index', '管理员管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('184', 'admin', '1', 'admin/authManager/index', '角色管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('185', 'admin', '1', 'admin/adminlog/index', '管理日志', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('186', 'admin', '1', 'admin/menu/add', '新增菜单', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('187', 'admin', '1', 'admin/menu/edit', '编辑菜单', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('188', 'admin', '1', 'admin/menu/delete', '删除菜单', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('189', 'attachment', '1', 'attachment/attachments/upload', '附件上传', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('190', 'attachment', '1', 'attachment/attachments/delete', '附件删除', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('191', 'addons', '1', 'addons/addons/index', '插件管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('192', 'addons', '1', 'addons/addons/hooks', '行为管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('193', 'addons', '1', 'addons/addons/addonadmin', '插件后台列表', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('194', 'admin', '1', 'admin/module/index', '模块后台列表', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('195', 'admin', '2', 'admin/main/index', '控制面板', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('196', 'attachment', '1', 'attachment/attachments/index', '附件管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('197', 'admin', '1', 'admin/config/add', '新增配置', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('198', 'admin', '2', 'admin/setting/index', '设置', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('199', 'admin', '1', 'admin/config/edit', '编辑配置', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('200', 'admin', '1', 'admin/config/del', '删除配置', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('201', 'admin', '2', 'admin/module/index', '模块', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('202', 'addons', '2', 'addons/addons/index', '扩展', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('211', 'cms', '1', 'cms/cms/index', '管理内容', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('212', 'cms', '1', 'cms/category/index', '栏目列表', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('213', 'cms', '1', 'cms/category/add', '添加栏目', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('214', 'cms', '1', 'cms/category/edit', '编辑栏目', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('215', 'cms', '1', 'cms/models/index', '模型管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('216', 'cms', '1', 'cms/field/index', '字段管理', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('217', 'cms', '1', 'cms/models/add', '添加模型', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('218', 'cms', '1', 'cms/models/edit', '修改模型', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('219', 'cms', '1', 'cms/models/delete', '删除模型', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('220', 'cms', '1', 'cms/models/setstate', '设置模型状态', '1', '');
INSERT INTO `yzn_auth_rule` VALUES ('221', 'cms', '2', 'cms/index/index', '内容', '1', '');

-- -----------------------------
-- Table structure for `yzn_cache`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_cache`;
CREATE TABLE `yzn_cache` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `key` char(100) NOT NULL DEFAULT '' COMMENT '缓存KEY值',
  `name` char(100) NOT NULL DEFAULT '' COMMENT '名称',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块名称',
  `model` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `action` char(30) NOT NULL DEFAULT '' COMMENT '方法名',
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否系统',
  PRIMARY KEY (`id`),
  KEY `ckey` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=208 DEFAULT CHARSET=utf8 COMMENT='缓存列队表';

-- -----------------------------
-- Records of `yzn_cache`
-- -----------------------------
INSERT INTO `yzn_cache` VALUES ('1', 'Config', '网站配置', 'admin', 'Config', 'config_cache', '1');
INSERT INTO `yzn_cache` VALUES ('2', 'Menu', '后台菜单', 'admin', 'Menu', 'menu_cache', '1');
INSERT INTO `yzn_cache` VALUES ('3', 'Module', '可用模块列表', 'admin', 'Module', 'module_cache', '1');
INSERT INTO `yzn_cache` VALUES ('204', 'Model', '模型列表', 'cms', 'Models', 'model_cache', '0');
INSERT INTO `yzn_cache` VALUES ('205', 'Category', '栏目索引', 'cms', 'Category', 'category_cache', '0');
INSERT INTO `yzn_cache` VALUES ('206', 'ModelField', '模型字段', 'cms', 'ModelField', 'model_field_cache', '0');
INSERT INTO `yzn_cache` VALUES ('207', 'Position', '推荐位', 'cms', 'Position', 'position_cache', '0');

-- -----------------------------
-- Table structure for `yzn_category`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_category`;
CREATE TABLE `yzn_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目ID',
  `catname` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `catdir` varchar(30) NOT NULL DEFAULT '' COMMENT '唯一标识',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类别',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `arrparentid` varchar(255) NOT NULL DEFAULT '' COMMENT '所有父ID',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否存在子栏目，1存在',
  `arrchildid` mediumtext NOT NULL COMMENT '所有子栏目ID',
  `image` mediumint(8) unsigned NOT NULL COMMENT '栏目图片',
  `description` mediumtext NOT NULL COMMENT '栏目描述',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '链接地址',
  `setting` mediumtext NOT NULL COMMENT '相关配置信息',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `relation` int(11) NOT NULL DEFAULT '0' COMMENT '是否为关联列表',
  `relationid` int(11) NOT NULL COMMENT '关联列表ID',
  `multiple` int(11) NOT NULL COMMENT '标签是否多选',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='栏目表';

-- -----------------------------
-- Records of `yzn_category`
-- -----------------------------
INSERT INTO `yzn_category` VALUES ('8', '系列标签', 'seriestags', '2', '10', '0', '', '0', '', '0', '', '', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '100', '0', '1', '0', '0');
INSERT INTO `yzn_category` VALUES ('9', '系列文章', 'series', '2', '8', '0', '', '0', '', '0', '', '', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '100', '1', '0', '8', '1');
INSERT INTO `yzn_category` VALUES ('10', '文章', 'news', '2', '11', '0', '', '0', '', '0', '', '', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '100', '1', '0', '0', '0');
INSERT INTO `yzn_category` VALUES ('11', '编程语言', 'code', '2', '10', '0', '', '0', '', '0', '', '', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '100', '0', '1', '0', '0');
INSERT INTO `yzn_category` VALUES ('12', '编程语言', 'coder', '2', '13', '0', '', '0', '', '0', '', '', 'a:7:{s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";s:17:\"category_template\";s:13:\"category.html\";s:13:\"list_template\";s:9:\"list.html\";s:13:\"show_template\";s:9:\"show.html\";s:13:\"page_template\";s:9:\"page.html\";}', '100', '1', '0', '11', '1');

-- -----------------------------
-- Table structure for `yzn_coder`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_coder`;
CREATE TABLE `yzn_coder` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `relation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '扩展内容',
  `posid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `hits` mediumint(8) unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='代码模型模型表';


-- -----------------------------
-- Table structure for `yzn_coder_data`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_coder_data`;
CREATE TABLE `yzn_coder_data` (
  `did` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `markdown` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='代码模型模型表';


-- -----------------------------
-- Table structure for `yzn_config`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_config`;
CREATE TABLE `yzn_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `options` varchar(255) NOT NULL DEFAULT '' COMMENT '配置项',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `listorder` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='网站配置';

-- -----------------------------
-- Records of `yzn_config`
-- -----------------------------
INSERT INTO `yzn_config` VALUES ('1', 'web_site_status', 'switch', '站点开关', 'base', '', '站点关闭后前台将不能访问', '1494408414', '1549703173', '1', '1', '1');
INSERT INTO `yzn_config` VALUES ('2', 'web_site_title', 'text', '站点标题', 'base', '', '', '1494408414', '1494408414', '1', 'YznCMS网站管理系统', '2');
INSERT INTO `yzn_config` VALUES ('3', 'web_site_keywords', 'text', '站点关键词', 'base', '', '', '1494408414', '1494408414', '1', 'YznCMS,网站管理系统', '3');
INSERT INTO `yzn_config` VALUES ('4', 'web_site_description', 'text', '站点描述', 'base', '', '', '1494408414', '1494408414', '1', '', '4');
INSERT INTO `yzn_config` VALUES ('5', 'web_site_logo', 'image', '站点LOGO', 'base', '', '', '1494408414', '1494408414', '1', '233', '5');
INSERT INTO `yzn_config` VALUES ('6', 'web_site_icp', 'text', '备案信息', 'base', '', '', '1494408414', '1546054403', '1', '', '6');
INSERT INTO `yzn_config` VALUES ('7', 'web_site_statistics', 'textarea', '站点代码', 'base', '', '', '1494408414', '1494408414', '1', '', '7');
INSERT INTO `yzn_config` VALUES ('8', 'config_group', 'array', '配置分组', 'system', '', '', '1494408414', '1494408414', '1', 'base:基础\r\nsystem:系统\r\nupload:上传\r\ndevelop:开发', '0');
INSERT INTO `yzn_config` VALUES ('14', 'upload_file_size', 'text', '文件上传大小限制', 'upload', '', '0为不限制大小，单位：kb', '1540457658', '1541756875', '1', '0', '99');
INSERT INTO `yzn_config` VALUES ('12', 'upload_image_size', 'text', '图片上传大小限制', 'upload', '', '0为不限制大小，单位：kb', '1540457656', '1541756842', '1', '0', '97');
INSERT INTO `yzn_config` VALUES ('15', 'upload_file_ext', 'text', '允许上传的文件后缀', 'upload', '', '多个后缀用逗号隔开，不填写则不限制类型', '1540457659', '1540457800', '1', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z', '100');
INSERT INTO `yzn_config` VALUES ('13', 'upload_image_ext', 'text', '允许上传的图片后缀', 'upload', '', '多个后缀用逗号隔开，不填写则不限制类型', '1540457657', '1541756856', '1', 'gif,jpg,jpeg,bmp,png', '98');
INSERT INTO `yzn_config` VALUES ('16', 'upload_driver', 'radio', '上传驱动', 'upload', 'local:本地', '图片或文件上传驱动', '1541752781', '1541756888', '1', 'local', '101');
INSERT INTO `yzn_config` VALUES ('9', 'theme', 'text', '主题风格', 'system', '', '或可在[界面]-[主题管理]中配置', '1541752781', '1541756888', '1', 'default', '1');

-- -----------------------------
-- Table structure for `yzn_field_type`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_field_type`;
CREATE TABLE `yzn_field_type` (
  `name` varchar(32) NOT NULL COMMENT '字段类型',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '中文类型名',
  `listorder` int(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `default_define` varchar(128) NOT NULL DEFAULT '' COMMENT '默认定义',
  `ifoption` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要设置选项',
  `ifstring` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否自由字符',
  `vrule` varchar(256) NOT NULL DEFAULT '' COMMENT '验证规则',
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='字段类型表';

-- -----------------------------
-- Records of `yzn_field_type`
-- -----------------------------
INSERT INTO `yzn_field_type` VALUES ('text', '输入框', '1', 'varchar(255) NOT NULL DEFAULT \'\'', '0', '1', '');
INSERT INTO `yzn_field_type` VALUES ('checkbox', '复选框', '2', 'varchar(32) NOT NULL DEFAULT \'\'', '1', '0', 'isChsAlphaNum');
INSERT INTO `yzn_field_type` VALUES ('textarea', '多行文本', '3', 'varchar(255) NOT NULL DEFAULT \'\'', '0', '1', '');
INSERT INTO `yzn_field_type` VALUES ('radio', '单选按钮', '4', 'varchar(32) NOT NULL DEFAULT \'\'', '1', '0', 'isChsAlphaNum');
INSERT INTO `yzn_field_type` VALUES ('switch', '开关', '5', 'tinyint(2) UNSIGNED NOT NULL DEFAULT \'0\'', '0', '0', 'isBool');
INSERT INTO `yzn_field_type` VALUES ('array', '数组', '6', 'varchar(512) NOT NULL DEFAULT \'\'', '0', '0', '');
INSERT INTO `yzn_field_type` VALUES ('select', '下拉框', '7', 'varchar(64) NOT NULL DEFAULT \'\'', '1', '0', 'isChsAlphaNum');
INSERT INTO `yzn_field_type` VALUES ('image', '单张图', '8', 'int(5) UNSIGNED NOT NULL DEFAULT \'0\'', '0', '0', 'isNumber');
INSERT INTO `yzn_field_type` VALUES ('tags', '标签', '10', 'varchar(255) NOT NULL DEFAULT \'\'', '0', '1', '');
INSERT INTO `yzn_field_type` VALUES ('number', '数字', '11', 'int(10) UNSIGNED NOT NULL DEFAULT \'0\'', '0', '0', 'isNumber');
INSERT INTO `yzn_field_type` VALUES ('datetime', '日期和时间', '12', 'int(11) UNSIGNED NOT NULL DEFAULT \'0\'', '0', '0', '');
INSERT INTO `yzn_field_type` VALUES ('Ueditor', '百度编辑器', '13', 'text NOT NULL', '0', '1', '');
INSERT INTO `yzn_field_type` VALUES ('images', '多张图', '9', 'varchar(256) NOT NULL DEFAULT \'\'', '0', '0', '');
INSERT INTO `yzn_field_type` VALUES ('color', '颜色值', '17', 'varchar(7) NOT NULL DEFAULT \'\'', '0', '0', '');
INSERT INTO `yzn_field_type` VALUES ('files', '多文件', '15', 'varchar(255) NOT NULL DEFAULT \'\'', '0', '0', '');
INSERT INTO `yzn_field_type` VALUES ('summernote', '简洁编辑器', '14', 'text NOT NULL', '0', '1', '');
INSERT INTO `yzn_field_type` VALUES ('file', '单文件', '16', 'int(5) UNSIGNED NOT NULL DEFAULT \'0\'', '0', '0', 'isNumber');
INSERT INTO `yzn_field_type` VALUES ('markdown', 'Markdown编辑器', '17', 'text NOT NULL', '0', '1', '');

-- -----------------------------
-- Table structure for `yzn_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_hooks`;
CREATE TABLE `yzn_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='插件钩子';

-- -----------------------------
-- Records of `yzn_hooks`
-- -----------------------------
INSERT INTO `yzn_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '1509174020', '');
INSERT INTO `yzn_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '1509174020', 'returntop');

-- -----------------------------
-- Table structure for `yzn_menu`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_menu`;
CREATE TABLE `yzn_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `app` char(20) NOT NULL DEFAULT '' COMMENT '应用标识',
  `controller` char(20) NOT NULL DEFAULT '' COMMENT '控制器标识',
  `action` char(20) NOT NULL DEFAULT '' COMMENT '方法标识',
  `parameter` char(255) NOT NULL DEFAULT '' COMMENT '附加参数',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否开发者可见',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '排序ID',
  PRIMARY KEY (`id`),
  KEY `pid` (`parentid`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `yzn_menu`
-- -----------------------------
INSERT INTO `yzn_menu` VALUES ('3', '设置', 'icon-shezhi', '0', 'admin', 'setting', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('4', '模块', 'icon-yingyong', '0', 'admin', 'module', 'index', '', '1', '', '0', '9');
INSERT INTO `yzn_menu` VALUES ('5', '扩展', 'icon-module', '0', 'addons', 'addons', 'index', '', '1', '', '0', '10');
INSERT INTO `yzn_menu` VALUES ('10', '系统配置', 'icon-zidongxiufu', '3', 'admin', 'config', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('11', '配置管理', 'icon-peizhi', '10', 'admin', 'config', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('13', '网站设置', 'icon-shezhi', '10', 'admin', 'config', 'setting', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('14', '菜单管理', 'icon-liebiao', '10', 'admin', 'menu', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('15', '权限管理', 'icon-guanliyuan', '3', 'admin', 'manager', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('20', '管理日志', 'icon-rizhi', '15', 'admin', 'adminlog', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('16', '管理员管理', 'icon-guanliyuan', '15', 'admin', 'manager', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('17', '角色管理', 'icon-chengyuan', '15', 'admin', 'authManager', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('1', '首页', '', '0', 'admin', 'index', 'index', '', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('2', '控制面板', '', '0', 'admin', 'main', 'index', '', '0', '', '0', '1');
INSERT INTO `yzn_menu` VALUES ('23', '附件管理', 'icon-fujian', '10', 'attachment', 'attachments', 'index', '', '1', '', '0', '1');
INSERT INTO `yzn_menu` VALUES ('24', '新增配置', '', '11', 'admin', 'config', 'add', '', '1', '', '0', '1');
INSERT INTO `yzn_menu` VALUES ('25', '编辑配置', '', '11', 'admin', 'config', 'edit', '', '1', '', '0', '2');
INSERT INTO `yzn_menu` VALUES ('26', '删除配置', '', '11', 'admin', 'config', 'del', '', '1', '', '0', '3');
INSERT INTO `yzn_menu` VALUES ('27', '新增菜单', '', '14', 'admin', 'menu', 'add', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('28', '编辑菜单', '', '14', 'admin', 'menu', 'edit', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('29', '删除菜单', '', '14', 'admin', 'menu', 'delete', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('30', '附件上传', '', '23', 'attachment', 'attachments', 'upload', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('31', '附件删除', '', '23', 'attachment', 'attachments', 'delete', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('32', '插件扩展', 'icon-module', '5', 'addons', 'addons', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('33', '插件管理', 'icon-plugins-', '32', 'addons', 'addons', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('34', '行为管理', 'icon-hangweifenxi', '32', 'addons', 'addons', 'hooks', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('35', '插件后台列表', 'icon-016', '5', 'addons', 'addons', 'addonadmin', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('36', '本地模块', 'icon-yingyong', '4', 'admin', 'module', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('37', '模块管理', 'icon-mokuaishezhi', '36', 'admin', 'module', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('38', '模块后台列表', 'icon-016', '4', 'admin', 'module', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('6', '界面', 'icon-jiemiansheji', '0', 'template', 'theme', 'index', '', '1', '', '0', '11');
INSERT INTO `yzn_menu` VALUES ('39', '模板风格', 'icon-jiemiansheji', '6', 'template', 'theme', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('40', '主题管理', 'icon-zhuti', '39', 'template', 'theme', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('143', '内容', 'icon-article', '0', 'cms', 'index', 'index', '', '1', '', '0', '3');
INSERT INTO `yzn_menu` VALUES ('144', '内容管理', 'icon-neirongguanli', '143', 'cms', 'cms', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('145', '管理内容', 'icon-neirongguanli', '144', 'cms', 'cms', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('146', '相关设置', 'icon-zidongxiufu', '143', 'cms', 'category', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('147', '栏目列表', 'icon-liebiao', '146', 'cms', 'category', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('148', '添加栏目', '', '147', 'cms', 'category', 'add', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('149', '编辑栏目', '', '147', 'cms', 'category', 'edit', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('150', '模型管理', 'icon-moxing', '146', 'cms', 'models', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('151', '字段管理', '', '150', 'cms', 'field', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('152', '添加模型', '', '150', 'cms', 'models', 'add', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('153', '修改模型', '', '150', 'cms', 'models', 'edit', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('154', '删除模型', '', '150', 'cms', 'models', 'delete', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('155', '设置模型状态', '', '150', 'cms', 'models', 'setstate', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('156', '推荐位管理', 'icon-tuijian', '146', 'cms', 'position', 'index', '', '1', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('157', '数据库备份', '', '35', 'addons', 'database', 'index', 'isadmin=1', '1', '数据库备份插件管理后台！', '0', '0');
INSERT INTO `yzn_menu` VALUES ('158', '备份还原', '', '35', 'addons', 'database', 'restore', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('159', '删除备份', '', '35', 'addons', 'database', 'del', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('160', '修复表', '', '35', 'addons', 'database', 'repair', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('161', '优化表', '', '35', 'addons', 'database', 'optimize', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('162', '还原表', '', '35', 'addons', 'database', 'import', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('163', '备份数据库', '', '35', 'addons', 'database', 'export', 'isadmin=1', '0', '', '0', '0');
INSERT INTO `yzn_menu` VALUES ('164', '备份数据库下载', '', '35', 'addons', 'database', 'download', 'isadmin=1', '0', '', '0', '0');

-- -----------------------------
-- Table structure for `yzn_model`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_model`;
CREATE TABLE `yzn_model` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `tablename` char(20) NOT NULL DEFAULT '' COMMENT '表名',
  `description` char(100) NOT NULL DEFAULT '' COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '模型类别：1-独立表，2-主附表',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `ifsub` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许投稿',
  `listorders` tinyint(3) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否禁用 1禁用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='内容模型列表';

-- -----------------------------
-- Records of `yzn_model`
-- -----------------------------
INSERT INTO `yzn_model` VALUES ('13', '代码模型', 'coder', '', '2', '1550245048', '1550245048', '0', '0', '1');
INSERT INTO `yzn_model` VALUES ('11', '文章模型', 'article', '', '2', '1549775818', '1549775818', '0', '0', '1');
INSERT INTO `yzn_model` VALUES ('10', '标签模型', 'tags', '', '1', '1549770803', '1549770803', '0', '0', '1');
INSERT INTO `yzn_model` VALUES ('8', '系列模型', 'series', '', '2', '1549770624', '1550245015', '0', '0', '1');

-- -----------------------------
-- Table structure for `yzn_model_field`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_model_field`;
CREATE TABLE `yzn_model_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '别名',
  `remark` tinytext NOT NULL COMMENT '字段提示',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '字段类型',
  `define` varchar(128) NOT NULL COMMENT '字段定义',
  `options` tinytext NOT NULL COMMENT '额外设置',
  `value` tinytext NOT NULL COMMENT '默认值',
  `jsonrule` tinytext NOT NULL COMMENT '关联规则',
  `ifsystem` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否主表字段 1 是',
  `ifeditable` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否可以编辑',
  `iffixed` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否固定不可修改',
  `ifrequire` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `ifsearch` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '作为搜索条件',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 禁用 1启用',
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`modelid`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 COMMENT='模型字段列表';

-- -----------------------------
-- Records of `yzn_model_field`
-- -----------------------------
INSERT INTO `yzn_model_field` VALUES ('200', '13', 'markdown', '内容', '', 'markdown', 'text NOT NULL', '', '', '', '0', '1', '0', '1', '0', '1550245122', '1550245195', '51', '1');
INSERT INTO `yzn_model_field` VALUES ('198', '13', 'did', '附表文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '0', '0', '1', '0', '0', '1550245048', '1550245048', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('197', '13', 'hits', '点击量', '', 'number', 'mediumint(8) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1550245048', '1550245087', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('194', '13', 'status', '状态', '', 'radio', 'tinyint(1)', '0:禁用\r\n1:启用', '1', '', '1', '1', '1', '0', '0', '1550245048', '1550245048', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('195', '13', 'inputtime', '创建时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1550245048', '1550245084', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('196', '13', 'updatetime', '更新时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1550245048', '1550245048', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('193', '13', 'listorder', '排序', '', 'number', 'smallint(5) UNSIGNED', '', '100', '', '1', '1', '1', '0', '0', '1550245048', '1550245191', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('192', '13', 'posid', '推荐位', '', 'checkbox', 'tinyint(3) UNSIGNED', '', '', '', '1', '0', '1', '0', '0', '1550245048', '1550245048', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('191', '13', 'uid', '用户id', '', 'number', 'mediumint(8) UNSIGNED', '', '1', '', '1', '0', '1', '0', '0', '1550245048', '1550245048', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('201', '11', 'content', '内容', '', 'Ueditor', 'text NOT NULL', '', '', '', '0', '1', '0', '1', '0', '1550585283', '1550585293', '51', '1');
INSERT INTO `yzn_model_field` VALUES ('165', '11', 'did', '附表文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '0', '0', '1', '0', '0', '1549775817', '1549775817', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('164', '11', 'hits', '点击量', '', 'number', 'mediumint(8) UNSIGNED', '', '0', '', '1', '1', '1', '0', '0', '1549775817', '1549775817', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('163', '11', 'updatetime', '更新时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549775817', '1549775817', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('160', '11', 'listorder', '排序', '', 'number', 'smallint(5) UNSIGNED', '', '100', '', '1', '1', '1', '0', '0', '1549775817', '1549897623', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('161', '11', 'status', '状态', '', 'radio', 'tinyint(1)', '0:禁用\r\n1:启用', '1', '', '1', '1', '1', '0', '0', '1549775817', '1549775817', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('162', '11', 'inputtime', '创建时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '1', '1', '0', '0', '1549775817', '1549775817', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('159', '11', 'posid', '推荐位', '', 'checkbox', 'tinyint(3) UNSIGNED', '', '', '', '1', '0', '1', '0', '0', '1549775817', '1549775817', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('158', '11', 'uid', '用户id', '', 'number', 'mediumint(8) UNSIGNED', '', '1', '', '1', '0', '1', '0', '0', '1549775817', '1549775817', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('157', '11', 'description', 'SEO摘要', '', 'textarea', 'varchar(255)', '', '', '', '1', '1', '0', '0', '0', '1549775817', '1549897619', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('156', '11', 'keywords', 'SEO关键词', '', 'text', 'varchar(255)', '', '', '{\"string\":{\"table\":\"tag\",\"key\":\"title\",\"delimiter\":\",\",\"where\":\"\",\"limit\":\"6\",\"order\":\"[rand]\"}}', '1', '1', '0', '0', '0', '1549775817', '1549897617', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('150', '10', 'hits', '点击量', '', 'number', 'mediumint(8) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770803', '1549898697', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('155', '11', 'relation', '扩展', '', 'text', 'varchar(255)', '', '', '', '1', '1', '1', '0', '0', '1549775817', '1549897613', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('149', '10', 'updatetime', '更新时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770803', '1549770803', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('146', '10', 'listorder', '排序', '', 'number', 'smallint(5) UNSIGNED', '', '100', '', '1', '1', '1', '0', '0', '1549770803', '1549770830', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('147', '10', 'status', '状态', '', 'radio', 'tinyint(1)', '0:禁用\n1:启用', '1', '', '1', '1', '1', '0', '0', '1549770803', '1549770803', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('148', '10', 'inputtime', '创建时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770803', '1549770825', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('145', '10', 'posid', '推荐位', '', 'checkbox', 'tinyint(3) UNSIGNED', '', '', '', '1', '0', '1', '0', '0', '1549770803', '1549770803', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('153', '11', 'catid', '栏目id', '', 'hidden', 'smallint(5) unsigned', '', '', '', '1', '1', '1', '0', '0', '1549775817', '1549897605', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('154', '11', 'title', '标题', '', 'text', 'varchar(255)', '', '', '', '1', '1', '0', '1', '1', '1549775817', '1549897608', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('152', '11', 'id', '文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '1', '1', '1', '0', '0', '1549775817', '1549775817', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('144', '10', 'uid', '用户id', '', 'number', 'mediumint(8) UNSIGNED', '', '1', '', '1', '0', '1', '0', '0', '1549770803', '1549770803', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('141', '10', 'relation', '扩展', '', 'text', 'varchar(255)', '', '', '', '1', '0', '1', '0', '0', '1549770803', '1549770821', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('140', '10', 'title', '标签名', '', 'text', 'varchar(255)', '', '', '', '1', '1', '0', '1', '1', '1549770803', '1549898748', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('139', '10', 'catid', '栏目id', '', 'hidden', 'smallint(5) unsigned', '', '', '', '1', '1', '1', '0', '0', '1549770803', '1549770803', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('138', '10', 'id', '文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '1', '1', '1', '0', '0', '1549770803', '1549770803', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('151', '8', 'markdown', '内容', '', 'markdown', 'text NOT NULL', '', '', '', '0', '1', '0', '1', '0', '1549775686', '1549897415', '51', '1');
INSERT INTO `yzn_model_field` VALUES ('122', '8', 'hits', '点击量', '', 'number', 'mediumint(8) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770623', '1549896131', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('123', '8', 'did', '附表文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '0', '0', '1', '0', '0', '1549770623', '1549770623', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('121', '8', 'updatetime', '更新时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770623', '1549770623', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('120', '8', 'inputtime', '创建时间', '', 'datetime', 'int(11) UNSIGNED', '', '0', '', '1', '0', '1', '0', '0', '1549770623', '1549896127', '200', '1');
INSERT INTO `yzn_model_field` VALUES ('119', '8', 'status', '状态', '', 'radio', 'tinyint(1)', '0:禁用\n1:启用', '1', '', '1', '1', '1', '0', '0', '1549770623', '1549770623', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('118', '8', 'listorder', '排序', '', 'number', 'smallint(5) UNSIGNED', '', '100', '', '1', '1', '1', '0', '0', '1549770623', '1549897411', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('117', '8', 'posid', '推荐位', '', 'checkbox', 'tinyint(3) UNSIGNED', '', '', '', '1', '0', '1', '0', '0', '1549770623', '1549770623', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('116', '8', 'uid', '用户id', '', 'number', 'mediumint(8) UNSIGNED', '', '1', '', '1', '0', '1', '0', '0', '1549770623', '1549770623', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('110', '8', 'id', '文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '1', '1', '1', '0', '0', '1549770623', '1549770623', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('111', '8', 'catid', '栏目id', '', 'hidden', 'smallint(5) unsigned', '', '', '', '1', '1', '1', '0', '0', '1549770623', '1549897393', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('112', '8', 'title', '标题', '', 'text', 'varchar(255)', '', '', '', '1', '1', '0', '1', '1', '1549770623', '1549897406', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('113', '8', 'relation', '扩展', '', 'text', 'varchar(255)', '', '', '', '1', '1', '1', '1', '0', '1549770623', '1549897409', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('114', '8', 'keywords', 'SEO关键词', '', 'text', 'varchar(255)', '', '', '{\"string\":{\"table\":\"tag\",\"key\":\"title\",\"delimiter\":\",\",\"where\":\"\",\"limit\":\"6\",\"order\":\"[rand]\"}}', '1', '1', '0', '0', '0', '1549770623', '1549897418', '55', '1');
INSERT INTO `yzn_model_field` VALUES ('115', '8', 'description', 'SEO摘要', '', 'textarea', 'varchar(255)', '', '', '', '1', '1', '0', '0', '0', '1549770623', '1549897421', '55', '1');
INSERT INTO `yzn_model_field` VALUES ('188', '13', 'relation', '扩展', '', 'text', 'varchar(255)', '', '', '', '1', '1', '1', '0', '0', '1550245048', '1550245189', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('185', '13', 'id', '文档id', '', 'hidden', 'mediumint(8) UNSIGNED', '', '', '', '1', '1', '1', '0', '0', '1550245048', '1550245048', '100', '1');
INSERT INTO `yzn_model_field` VALUES ('186', '13', 'catid', '栏目id', '', 'hidden', 'smallint(5) unsigned', '', '', '', '1', '1', '1', '0', '0', '1550245048', '1550245186', '50', '1');
INSERT INTO `yzn_model_field` VALUES ('187', '13', 'title', '标题', '', 'text', 'varchar(255)', '', '', '', '1', '1', '0', '1', '1', '1550245048', '1550245188', '50', '1');

-- -----------------------------
-- Table structure for `yzn_module`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_module`;
CREATE TABLE `yzn_module` (
  `module` varchar(15) NOT NULL COMMENT '模块',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模块名称',
  `sign` varchar(255) NOT NULL DEFAULT '' COMMENT '签名',
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '内置模块',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否可用',
  `version` varchar(50) NOT NULL DEFAULT '' COMMENT '版本',
  `setting` mediumtext COMMENT '设置信息',
  `installtime` int(10) NOT NULL DEFAULT '0' COMMENT '安装时间',
  `updatetime` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`module`),
  KEY `sign` (`sign`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='已安装模块列表';

-- -----------------------------
-- Records of `yzn_module`
-- -----------------------------
INSERT INTO `yzn_module` VALUES ('cms', 'cms模块', 'b19cc279ed484c13c96c2f7142e2f437', '0', '1', '1.0.0', '', '1547997177', '1547997177', '0');

-- -----------------------------
-- Table structure for `yzn_page`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_page`;
CREATE TABLE `yzn_page` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(160) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `content` text COMMENT '内容',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='单页内容表';


-- -----------------------------
-- Table structure for `yzn_position`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_position`;
CREATE TABLE `yzn_position` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '推荐位id',
  `modelid` mediumint(5) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `catid` varchar(255) NOT NULL DEFAULT '' COMMENT '栏目id',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '推荐位名称',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='推荐位';

-- -----------------------------
-- Records of `yzn_position`
-- -----------------------------
INSERT INTO `yzn_position` VALUES ('1', '0', '0', '首页幻灯片', '1500272764', '1500519504', '1');
INSERT INTO `yzn_position` VALUES ('2', '0', '0', '首页文字推荐', '1500272764', '1500519504', '2');
INSERT INTO `yzn_position` VALUES ('3', '0', '0', '首页图片推荐', '1500272764', '1500519504', '3');

-- -----------------------------
-- Table structure for `yzn_position_data`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_position_data`;
CREATE TABLE `yzn_position_data` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '文章ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `posid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位ID',
  `modelid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '模型ID',
  KEY `posid` (`posid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='推荐位数据表';


-- -----------------------------
-- Table structure for `yzn_series`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_series`;
CREATE TABLE `yzn_series` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `relation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '扩展内容',
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `posid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `hits` mediumint(8) unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='系列模型模型表';

-- -----------------------------
-- Records of `yzn_series`
-- -----------------------------
INSERT INTO `yzn_series` VALUES ('2', '9', 'ttt', 'css,python,javascript', '', '', '0', '100', '0', '0', '1550059368', '1550060734', '1');

-- -----------------------------
-- Table structure for `yzn_series_data`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_series_data`;
CREATE TABLE `yzn_series_data` (
  `did` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `markdown` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='系列模型模型表';

-- -----------------------------
-- Records of `yzn_series_data`
-- -----------------------------
INSERT INTO `yzn_series_data` VALUES ('2', 'ttt');

-- -----------------------------
-- Table structure for `yzn_tags`
-- -----------------------------
DROP TABLE IF EXISTS `yzn_tags`;
CREATE TABLE `yzn_tags` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目ID',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标签名',
  `relation` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '扩展内容',
  `posid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `hits` mediumint(8) unsigned DEFAULT '0' COMMENT '点击量',
  `inputtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='标签模型模型表';

-- -----------------------------
-- Records of `yzn_tags`
-- -----------------------------
INSERT INTO `yzn_tags` VALUES ('1', '8', 'javascript', '', '0', '100', '0', '0', '1549771014', '1549898896', '1');
INSERT INTO `yzn_tags` VALUES ('2', '8', 'css', '', '0', '100', '0', '0', '1549771018', '1549771018', '1');
INSERT INTO `yzn_tags` VALUES ('3', '8', 'python', '', '0', '100', '0', '0', '1549771025', '1549771025', '1');
INSERT INTO `yzn_tags` VALUES ('5', '11', 'canvas', '', '0', '100', '0', '0', '1549777034', '1549777034', '1');
